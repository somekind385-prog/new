@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.example.fpsoverlay

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.abs

private fun nearest(values: List<Float>, v: Float): Int {
    var best = 0
    for (i in values.indices) if (abs(values[i] - v) < abs(values[best] - v)) best = i
    return best
}

@Composable
fun MacroSection() {
    val ctx = LocalContext.current
    val version by MacroStore.version.collectAsState()
    var macros by remember { mutableStateOf<List<Macro>>(emptyList()) }
    LaunchedEffect(version) {
        macros = withContext(Dispatchers.IO) { MacroStore.list(ctx) }
    }
    var serviceOn by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        while (true) {
            serviceOn = MacroAccessibilityService.instance != null
            delay(1000)
        }
    }
    var panelOn by remember { mutableStateOf(MacroStore.panelVisible(ctx)) }
    var pauseOn by remember { mutableStateOf(MacroStore.pauseOnTouch(ctx)) }
    var renaming by remember { mutableStateOf<Macro?>(null) }
    val selectedId = remember(version) { MacroStore.selectedId(ctx) }

    fun clipboard() = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager

    Section("Автокликер и макросы") {
        if (!serviceOn) {
            Text(
                "Служба специальных возможностей выключена. Нажмите кнопку ниже, найдите в списке " +
                    "«FPS Overlay: автокликер и макросы» и включите. Если переключатель серый (Android 13 и новее): " +
                    "Настройки → Приложения → FPS Overlay → ⋮ → «Разрешить ограниченные настройки», потом повторите.",
                style = MaterialTheme.typography.bodySmall,
            )
            Button(
                onClick = {
                    ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Открыть настройки специальных возможностей") }
        } else {
            Text(
                "Служба включена. Откройте игру: на панели ● запись, ▶ запуск выбранного макроса, ■ остановка, ⠿ перетащить.",
                color = MaterialTheme.colorScheme.secondary,
            )
        }

        SwitchRow("Панель управления на экране", panelOn) { v ->
            panelOn = v
            MacroStore.setPanelVisible(ctx, v)
            MacroAccessibilityService.instance?.setPanelVisible(v)
        }

        SwitchRow("Не мешать моим касаниям (нужен Shizuku)", pauseOn) { v ->
            pauseOn = v
            MacroStore.setPauseOnTouch(ctx, v)
            if (v && !ShizukuShell.isReady()) {
                Toast.makeText(ctx, "Для этого режима нужен запущенный Shizuku", Toast.LENGTH_LONG).show()
            }
        }
        Text(
            "Android по своим правилам прерывает текущее касание пользователя, когда служба вставляет своё. " +
                "Режим следит за вашим пальцем и делает клики только пока палец поднят. Без него макрос может сбивать " +
                "ваши нажатия (например, удержание джойстика). Если нужно кликать, пока вы держите палец, режим лучше выключить.",
            style = MaterialTheme.typography.bodySmall,
        )

        OutlinedButton(
            onClick = {
                val text = try {
                    clipboard().primaryClip?.getItemAt(0)?.coerceToText(ctx)?.toString().orEmpty()
                } catch (e: Throwable) {
                    ""
                }
                val m = decodeShare(text)
                if (m == null) {
                    Toast.makeText(ctx, "В буфере нет конфига макроса", Toast.LENGTH_SHORT).show()
                } else {
                    val saved = m.copy(id = MacroStore.newId(), created = System.currentTimeMillis())
                    MacroStore.save(ctx, saved)
                    MacroStore.setSelected(ctx, saved.id)
                    Toast.makeText(ctx, "Добавлено: ${saved.name}", Toast.LENGTH_SHORT).show()
                }
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Вставить конфиг из буфера") }

        if (macros.isEmpty()) {
            Text(
                "Макросов пока нет. Откройте игру и нажмите ● на панели, выполните нужные нажатия и нажмите ■. " +
                    "Для автокликера запишите одно нажатие и поставьте «Повторов: ∞» и нужную паузу.",
                style = MaterialTheme.typography.bodySmall,
            )
        }

        for (m in macros) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = m.id == selectedId, onClick = { MacroStore.setSelected(ctx, m.id) })
                    Column {
                        Text(m.name)
                        Text(
                            "шагов ${m.steps.size}, около ${"%.1f".format(m.durationMs() / 1000.0)} с, " +
                                if (m.land) "альбомная" else "портретная",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
                FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = {
                        clipboard().setPrimaryClip(ClipData.newPlainText("macro", encodeShare(m)))
                        Toast.makeText(ctx, "Конфиг скопирован", Toast.LENGTH_SHORT).show()
                    }) { Text("Копировать") }
                    TextButton(onClick = {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, encodeShare(m))
                        }
                        ctx.startActivity(Intent.createChooser(send, "Отправить конфиг").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }) { Text("Отправить") }
                    TextButton(onClick = { renaming = m }) { Text("Имя") }
                    TextButton(onClick = { MacroStore.delete(ctx, m.id) }) { Text("Удалить") }
                }
            }
        }

        val sel = macros.firstOrNull { it.id == selectedId }
        if (sel != null) {
            Text("Выбран: ${sel.name}", style = MaterialTheme.typography.titleSmall)

            val loopVals = listOf(1, 5, 10, 50, 0)
            Text("Повторов")
            ChipRow(listOf("1×", "5×", "10×", "50×", "∞"), loopVals.indexOf(sel.loops)) { i ->
                MacroStore.save(ctx, sel.copy(loops = loopVals[i]))
            }

            val delayVals = listOf(0, 50, 100, 300, 1000, 3000)
            Text("Пауза между повторами")
            ChipRow(listOf("0", "0.05 с", "0.1 с", "0.3 с", "1 с", "3 с"), delayVals.indexOf(sel.loopDelayMs)) { i ->
                MacroStore.save(ctx, sel.copy(loopDelayMs = delayVals[i]))
            }

            val speedVals = listOf(0.5f, 1f, 1.5f, 2f, 3f)
            Text("Скорость")
            ChipRow(listOf("0.5×", "1×", "1.5×", "2×", "3×"), nearest(speedVals, sel.speed)) { i ->
                MacroStore.save(ctx, sel.copy(speed = speedVals[i]))
            }
        }

        Text(
            "Запись: слой на весь экран ловит касания, поэтому во время записи игра на них не реагирует. " +
                "Запускайте только конфиги от тех, кому доверяете: макрос нажимает на экран от вашего имени. " +
                "Во многих онлайн-играх автоматизация запрещена правилами. Не ставьте панель туда, куда кликает макрос.",
            style = MaterialTheme.typography.bodySmall,
        )

        renaming?.let { r ->
            var text by remember(r.id) { mutableStateOf(r.name) }
            AlertDialog(
                onDismissRequest = { renaming = null },
                title = { Text("Название макроса") },
                text = {
                    OutlinedTextField(
                        value = text,
                        onValueChange = { text = it.take(60) },
                        singleLine = true,
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        MacroStore.save(ctx, r.copy(name = text.trim().ifBlank { r.name }))
                        renaming = null
                    }) { Text("Сохранить") }
                },
                dismissButton = { TextButton(onClick = { renaming = null }) { Text("Отмена") } },
            )
        }
    }
}
