package com.example.fpsoverlay

import android.content.Context
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.overlayStore by preferencesDataStore(name = "overlay_settings")

private object K {
    val scale = floatPreferencesKey("scale")
    val fontSize = intPreferencesKey("fontSize")
    val showFps = booleanPreferencesKey("showFps")
    val showCpu = booleanPreferencesKey("showCpu")
    val showCores = booleanPreferencesKey("showCores")
    val showTemp = booleanPreferencesKey("showTemp")
    val showRam = booleanPreferencesKey("showRam")
    val horizontal = booleanPreferencesKey("horizontal")
    val intervalMs = intPreferencesKey("intervalMs")
    val bgMode = intPreferencesKey("bgMode")
    val bgAlpha = floatPreferencesKey("bgAlpha")
    val bgColor = intPreferencesKey("bgColor")
    val customImageUri = stringPreferencesKey("customImageUri")
    val textColor = intPreferencesKey("textColor")
    val fpsColor = intPreferencesKey("fpsColor")
    val fpsDynamic = booleanPreferencesKey("fpsDynamic")
    val corner = intPreferencesKey("corner")
    val borderWidth = intPreferencesKey("borderWidth")
    val borderColor = intPreferencesKey("borderColor")
    val textShadow = booleanPreferencesKey("textShadow")
    val fontFamily = intPreferencesKey("fontFamily")
    val decor = intPreferencesKey("decor")
    val themeMode = intPreferencesKey("themeMode")
    val shizuku = booleanPreferencesKey("shizuku")
    val posX = intPreferencesKey("posX")
    val posY = intPreferencesKey("posY")
}

private fun Preferences.toSettings(): OverlaySettings {
    val d = OverlaySettings()
    return OverlaySettings(
        scale = this[K.scale] ?: d.scale,
        fontSize = this[K.fontSize] ?: d.fontSize,
        showFps = this[K.showFps] ?: d.showFps,
        showCpu = this[K.showCpu] ?: d.showCpu,
        showCores = this[K.showCores] ?: d.showCores,
        showTemp = this[K.showTemp] ?: d.showTemp,
        showRam = this[K.showRam] ?: d.showRam,
        horizontal = this[K.horizontal] ?: d.horizontal,
        intervalMs = this[K.intervalMs] ?: d.intervalMs,
        bgMode = this[K.bgMode] ?: d.bgMode,
        bgAlpha = this[K.bgAlpha] ?: d.bgAlpha,
        bgColor = this[K.bgColor] ?: d.bgColor,
        customImageUri = this[K.customImageUri] ?: d.customImageUri,
        textColor = this[K.textColor] ?: d.textColor,
        fpsColor = this[K.fpsColor] ?: d.fpsColor,
        fpsDynamic = this[K.fpsDynamic] ?: d.fpsDynamic,
        corner = this[K.corner] ?: d.corner,
        borderWidth = this[K.borderWidth] ?: d.borderWidth,
        borderColor = this[K.borderColor] ?: d.borderColor,
        textShadow = this[K.textShadow] ?: d.textShadow,
        fontFamily = this[K.fontFamily] ?: d.fontFamily,
        decor = this[K.decor] ?: d.decor,
        themeMode = this[K.themeMode] ?: d.themeMode,
        shizuku = this[K.shizuku] ?: d.shizuku,
        posX = this[K.posX] ?: d.posX,
        posY = this[K.posY] ?: d.posY,
    )
}

private fun MutablePreferences.write(s: OverlaySettings) {
    this[K.scale] = s.scale
    this[K.fontSize] = s.fontSize
    this[K.showFps] = s.showFps
    this[K.showCpu] = s.showCpu
    this[K.showCores] = s.showCores
    this[K.showTemp] = s.showTemp
    this[K.showRam] = s.showRam
    this[K.horizontal] = s.horizontal
    this[K.intervalMs] = s.intervalMs
    this[K.bgMode] = s.bgMode
    this[K.bgAlpha] = s.bgAlpha
    this[K.bgColor] = s.bgColor
    this[K.customImageUri] = s.customImageUri
    this[K.textColor] = s.textColor
    this[K.fpsColor] = s.fpsColor
    this[K.fpsDynamic] = s.fpsDynamic
    this[K.corner] = s.corner
    this[K.borderWidth] = s.borderWidth
    this[K.borderColor] = s.borderColor
    this[K.textShadow] = s.textShadow
    this[K.fontFamily] = s.fontFamily
    this[K.decor] = s.decor
    this[K.themeMode] = s.themeMode
    this[K.shizuku] = s.shizuku
    this[K.posX] = s.posX
    this[K.posY] = s.posY
}

class SettingsRepository(context: Context) {
    private val store = context.applicationContext.overlayStore

    val flow: Flow<OverlaySettings> = store.data.map { it.toSettings() }

    suspend fun update(block: (OverlaySettings) -> OverlaySettings) {
        store.edit { prefs -> prefs.write(block(prefs.toSettings())) }
    }
}
