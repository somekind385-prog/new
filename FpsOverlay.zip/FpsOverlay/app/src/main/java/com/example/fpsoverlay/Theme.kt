package com.example.fpsoverlay

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Lavender = Color(0xFFC9A7F0)
val Violet = Color(0xFF7B3FE4)
val Navy = Color(0xFF3A3F8F)
val Pink = Color(0xFFFF6FB5)

private val LightScheme = lightColorScheme(
    primary = Color(0xFF1E4FA8),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFCFE3FF),
    onPrimaryContainer = Color(0xFF0A1B4D),
    secondary = Color(0xFF9A6B12),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFE9B8),
    onSecondaryContainer = Color(0xFF3A2A00),
    background = Color(0xFFF5F8FF),
    onBackground = Color(0xFF0A1236),
    surface = Color(0xFFF5F8FF),
    onSurface = Color(0xFF0A1236),
    surfaceVariant = Color(0xFFE1ECFF),
    onSurfaceVariant = Color(0xFF16275E),
)

// Палитра из арта: ночное синее небо, голубые волосы, золото отделки
private val DarkScheme = darkColorScheme(
    primary = Color(0xFF8CC8FF),
    onPrimary = Color(0xFF06214A),
    primaryContainer = Color(0xFF1E4FA8),
    onPrimaryContainer = Color.White,
    secondary = Color(0xFFE8C170),
    onSecondary = Color(0xFF3A2A00),
    secondaryContainer = Color(0xFF6A4A1F),
    onSecondaryContainer = Color(0xFFFFE9B8),
    background = Color(0xFF0A1236),
    onBackground = Color(0xFFE6EEFF),
    surface = Color(0xFF0A1236),
    onSurface = Color(0xFFE6EEFF),
    surfaceVariant = Color(0xFF16275E),
    onSurfaceVariant = Color(0xFFD3E2FF),
)

@Composable
fun AppTheme(mode: Int, forceDark: Boolean = false, content: @Composable () -> Unit) {
    val dark = if (forceDark) true else when (mode) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    MaterialTheme(colorScheme = if (dark) DarkScheme else LightScheme, content = content)
}
