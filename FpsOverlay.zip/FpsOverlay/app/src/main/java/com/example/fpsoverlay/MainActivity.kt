@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.example.fpsoverlay

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {

    private lateinit var repo: SettingsRepository
    private lateinit var collector: StatsCollector

    @Volatile
    private var latest = OverlaySettings()

    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo = SettingsRepository(this)
        collector = StatsCollector(this)

        setContent {
            val settings by repo.flow.collectAsState(initial = OverlaySettings())
            SideEffect { latest = settings }
            val scope = rememberCoroutineScope()
            val update: ((OverlaySettings) -> OverlaySettings) -> Unit = { f ->
                scope.launch { repo.update(f) }
            }
            AppTheme(settings.themeMode, settings.appBgPicture) {
                Surface(Modifier.fillMaxSize()) {
                    MainScreen(
                        s = settings,
                        stats = collector.stats,
                        update = update,
                        onStart = ::startOverlay,
                        onStop = ::stopOverlay,
                    )
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        collector.start(lifecycleScope) { latest }
    }

    override fun onPause() {
        collector.stop()
        super.onPause()
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Разрешите показ поверх других приложений", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
    }

    private fun stopOverlay() {
        stopService(Intent(this, OverlayService::class.java))
    }
}

@Composable
private fun MainScreen(
    s: OverlaySettings,
    stats: StateFlow<Stats>,
    update: ((OverlaySettings) -> OverlaySettings) -> Unit,
    onStart: () -> Unit,
    onStop: () -> Unit,
) {
    val ctx = LocalContext.current
    val st by stats.collectAsState()
    val running by OverlayService.running.collectAsState()

    fun takePerm(uri: Uri) {
        try {
            ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: Throwable) {
            // не все провайдеры дают постоянный доступ
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            takePerm(uri)
            update { it.copy(customImageUri = uri.toString(), bgMode = BG_CUSTOM_IMAGE) }
        }
    }
    val decorPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            takePerm(uri)
            update { it.copy(decorImageUri = uri.toString(), decor = 3) }
        }
    }
    val avatarPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            takePerm(uri)
            update { it.copy(avatarUri = uri.toString()) }
        }
    }

    var shizukuRunning by remember { mutableStateOf(false) }
    var shizukuGranted by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        while (true) {
            shizukuRunning = ShizukuShell.isRunning()
            shizukuGranted = ShizukuShell.hasPermission()
            delay(1500)
        }
    }

    Box(Modifier.fillMaxSize()) {
    if (s.appBgPicture) {
        Image(
            painter = painterResource(R.drawable.app_bg),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop,
        )
        Box(
            Modifier
                .fillMaxSize()
                .background(Color(0xFF060A22).copy(alpha = s.appBgDim))
        )
    }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            AvatarImage(s.avatarUri, 56.dp)
            Text("FPS Overlay", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary)
        }

        // ---------- Предпросмотр ----------
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF16275E), Color(0xFF3B7DD8))))
                .padding(20.dp),
            contentAlignment = Alignment.Center,
        ) {
            OverlayBadge(stats = st, s = s)
        }

        Button(
            onClick = if (running) onStop else onStart,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text(if (running) "Остановить оверлей" else "Запустить оверлей")
        }

        // ---------- Вид плашки ----------
        Section("Вид плашки") {
            ChipRow(listOf("Полный", "Компакт", "Минимум", "Только FPS"), s.badgeStyle) { i ->
                update { it.copy(badgeStyle = i) }
            }
            Text(
                when (s.badgeStyle) {
                    1 -> "Одна строка с короткими подписями, без декора. Компоновка и ядра CPU не используются."
                    2 -> "Одна строка, только числа, без подписей и декора."
                    3 -> "Только число FPS, остальные показатели скрыты."
                    else -> "Прежний вид: подписи, декор, вертикальная или горизонтальная компоновка, ядра CPU."
                },
                style = MaterialTheme.typography.bodySmall,
            )
        }

        // ---------- Что показывать ----------
        Section("Что показывать") {
            SwitchRow("FPS", s.showFps) { v -> update { it.copy(showFps = v) } }
            SwitchRow("CPU общий", s.showCpu) { v -> update { it.copy(showCpu = v) } }
            SwitchRow("CPU по ядрам", s.showCores) { v -> update { it.copy(showCores = v) } }
            SwitchRow("Температура батареи", s.showTemp) { v -> update { it.copy(showTemp = v) } }
            SwitchRow("RAM", s.showRam) { v -> update { it.copy(showRam = v) } }
            SwitchRow("Frametime и 1% low (Shizuku)", s.showFrame) { v -> update { it.copy(showFrame = v) } }
            SwitchRow("Температура CPU", s.showCpuTemp) { v -> update { it.copy(showCpuTemp = v) } }
            SwitchRow("Нагрузка GPU (если отдаёт прошивка)", s.showGpu) { v -> update { it.copy(showGpu = v) } }
            SwitchRow("Пинг и потери пакетов", s.showPing) { v -> update { it.copy(showPing = v) } }
            if (s.showPing) {
                var host by remember(s.pingHost) { mutableStateOf(s.pingHost) }
                OutlinedTextField(
                    value = host,
                    onValueChange = { value ->
                        host = value
                        update { cur -> cur.copy(pingHost = value) }
                    },
                    singleLine = true,
                    label = { Text("Сервер для пинга (адрес или адрес:порт)") },
                    modifier = Modifier.fillMaxWidth(),
                )
                Text(
                    "Пинг считается как время TCP-соединения с этим сервером (по умолчанию 1.1.1.1:443). " +
                        "Для пинга до сервера игры впишите его адрес, если знаете.",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
            SwitchRow("Скорость сети (всё устройство)", s.showNet) { v -> update { it.copy(showNet = v) } }
            SwitchRow("Потребление батареи, Вт", s.showPower) { v -> update { it.copy(showPower = v) } }
            Text("Компоновка")
            ChipRow(listOf("Вертикальная", "Горизонтальная"), if (s.horizontal) 1 else 0) { i ->
                update { it.copy(horizontal = i == 1) }
            }
            Text("Интервал обновления")
            val intervals = listOf(100, 200, 500, 1000, 2000)
            ChipRow(listOf("0.1 с", "0.2 с", "0.5 с", "1 с", "2 с"), intervals.indexOf(s.intervalMs).coerceAtLeast(0)) { i ->
                update { it.copy(intervalMs = intervals[i]) }
            }
            Text(
                "С Shizuku каждый замер идёт через shell (около 0.1 с), поэтому быстрее 0.1 с не получится.",
                style = MaterialTheme.typography.bodySmall,
            )
        }

        // ---------- Размер ----------
        Section("Размер") {
            SliderRow("Масштаб плашки: ${(s.scale * 100).roundToInt()}%", s.scale, 0.5f..3f) { v ->
                update { it.copy(scale = v) }
            }
            SliderRow("Размер шрифта: ${s.fontSize} sp", s.fontSize.toFloat(), 8f..40f) { v ->
                update { it.copy(fontSize = v.roundToInt()) }
            }
            Text("Плашку можно перетаскивать пальцем и масштабировать щипком двумя пальцами.")
        }

        // ---------- Фон ----------
        Section("Фон плашки") {
            ChipRow(listOf("Картинка", "Своя", "Цвет", "Прозрачный"), s.bgMode) { i ->
                update { it.copy(bgMode = i) }
            }
            if (s.bgMode != BG_TRANSPARENT) {
                SliderRow("Прозрачность фона: ${(s.bgAlpha * 100).roundToInt()}%", s.bgAlpha, 0f..1f) { v ->
                    update { it.copy(bgAlpha = v) }
                }
            }
            if (s.bgMode == BG_CUSTOM_IMAGE) {
                OutlinedButton(onClick = { picker.launch(arrayOf("image/*")) }) {
                    Text("Выбрать из галереи")
                }
            }
            if (s.bgMode == BG_SOLID) {
                ColorSetting("Цвет фона", s.bgColor) { c -> update { it.copy(bgColor = c) } }
            }
        }

        // ---------- Оформление ----------
        Section("Оформление") {
            ColorSetting("Цвет текста", s.textColor) { c -> update { it.copy(textColor = c) } }
            SwitchRow("FPS от красного к зелёному", s.fpsDynamic) { v -> update { it.copy(fpsDynamic = v) } }
            ColorSetting("Цвет значений", s.fpsColor) { c -> update { it.copy(fpsColor = c) } }
            SliderRow("Скругление углов: ${s.corner}", s.corner.toFloat(), 0f..40f) { v ->
                update { it.copy(corner = v.roundToInt()) }
            }
            SliderRow("Обводка: ${s.borderWidth}", s.borderWidth.toFloat(), 0f..8f) { v ->
                update { it.copy(borderWidth = v.roundToInt()) }
            }
            ColorSetting("Цвет обводки", s.borderColor) { c -> update { it.copy(borderColor = c) } }
            SwitchRow("Тень текста", s.textShadow) { v -> update { it.copy(textShadow = v) } }
            Text("Шрифт")
            ChipRow(listOf("Системный", "Моно", "С засечками", "Рукописный", "Sans"), s.fontFamily) { i ->
                update { it.copy(fontFamily = i) }
            }
            Text("Декор")
            ChipRow(listOf("Нет", "Бабочка", "Сердечки", "Своё фото"), s.decor) { i -> update { it.copy(decor = i) } }
            if (s.decor == 3) {
                OutlinedButton(onClick = { decorPicker.launch(arrayOf("image/*")) }) {
                    Text(if (s.decorImageUri.isBlank()) "Выбрать фото для декора" else "Заменить фото декора")
                }
                SliderRow("Размер декора: ${(s.decorScale * 100).roundToInt()}%", s.decorScale, 0.5f..2.5f) { v ->
                    update { it.copy(decorScale = v) }
                }
            }
        }

        // ---------- Аватарка ----------
        Section("Аватарка приложения") {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                AvatarImage(s.avatarUri, 72.dp)
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = { avatarPicker.launch(arrayOf("image/*")) }) { Text("Выбрать картинку") }
                    if (s.avatarUri.isNotBlank()) {
                        OutlinedButton(onClick = { update { it.copy(avatarUri = "") } }) { Text("Сбросить") }
                    }
                }
            }
            Button(
                onClick = {
                    val msg = when (pinIconShortcut(ctx, s.avatarUri)) {
                        0 -> "Подтвердите добавление ярлыка на рабочий стол"
                        1 -> "Лаунчер не поддерживает создание ярлыков. Включите для приложения разрешение «Ярлыки на рабочем столе»"
                        2 -> "Не удалось прочитать картинку"
                        else -> "Не удалось создать ярлык"
                    }
                    Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Создать ярлык с этой аватаркой") }
            Text(
                "Android не позволяет приложению заменить свой значок в лаунчере. Поэтому создаётся ярлык на " +
                    "рабочем столе с вашей картинкой (старый значок можно убрать с рабочего стола вручную). " +
                    "Если ярлык не появился, в настройках приложения выдайте разрешение на ярлыки рабочего стола.",
                style = MaterialTheme.typography.bodySmall,
            )
        }

        // ---------- Тема ----------
        Section("Тема приложения") {
            SwitchRow("Фон-картинка", s.appBgPicture) { v -> update { it.copy(appBgPicture = v) } }
            if (s.appBgPicture) {
                SliderRow("Затемнение фона: ${(s.appBgDim * 100).roundToInt()}%", s.appBgDim, 0f..0.9f) { v ->
                    update { it.copy(appBgDim = v) }
                }
            } else {
                ChipRow(listOf("Системная", "Светлая", "Тёмная"), s.themeMode) { i ->
                    update { it.copy(themeMode = i) }
                }
            }
        }

        // ---------- Shizuku ----------
        Section("Shizuku (FPS других приложений и CPU)") {
            SwitchRow("Использовать Shizuku", s.shizuku) { v -> update { it.copy(shizuku = v) } }
            val status = when {
                !shizukuRunning -> "Shizuku не запущен или не установлен"
                !shizukuGranted -> "Shizuku запущен, но разрешение не выдано"
                else -> "Shizuku готов к работе"
            }
            Text("Статус: $status", color = MaterialTheme.colorScheme.secondary)
            if (shizukuRunning && !shizukuGranted) {
                Button(onClick = { ShizukuShell.requestPermission() }) { Text("Выдать разрешение Shizuku") }
            }
            Text("Режим FPS сейчас: ${st.fpsMode}")
            Text("Режим CPU сейчас: ${st.cpuMode}")
            Text("Датчики (темп. CPU, GPU): ${st.sysMode}")
            Text("Пинг: ${st.pingMode}")
            Text(
                "Как включить:\n" +
                    "1. Установите приложение Shizuku (Google Play или GitHub RikkaApps/Shizuku).\n" +
                    "2. Включите «Параметры разработчика» и «Отладку по USB» (на Android 11+ — «Отладку по Wi-Fi»).\n" +
                    "3. Откройте Shizuku и запустите его: на Android 11+ через беспроводную отладку прямо на телефоне, " +
                    "на более старых — командой adb с компьютера (инструкция внутри Shizuku).\n" +
                    "4. Вернитесь сюда, включите переключатель выше и нажмите «Выдать разрешение Shizuku».\n" +
                    "После перезагрузки телефона Shizuku нужно запускать заново (без root).",
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }
    }
}

@Composable
private fun AvatarImage(uri: String, size: Dp) {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(null, uri) {
        value = if (uri.isBlank()) null else loadBitmap(ctx, uri)
    }
    val b = bmp
    val mod = Modifier.size(size).clip(CircleShape)
    if (b != null) {
        Image(bitmap = b, contentDescription = null, modifier = mod, contentScale = ContentScale.Crop)
    } else {
        Image(
            painter = painterResource(R.drawable.avatar_default),
            contentDescription = null,
            modifier = mod,
            contentScale = ContentScale.Crop,
        )
    }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.82f),
        ),
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            content()
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun SliderRow(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    var local by remember(value) { mutableStateOf(value) }
    Column {
        Text(label)
        Slider(
            value = local,
            onValueChange = {
                local = it
                onChange(it)
            },
            valueRange = range,
        )
    }
}

@Composable
private fun ChipRow(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEachIndexed { i, label ->
            FilterChip(
                selected = i == selected,
                onClick = { onSelect(i) },
                label = { Text(label) },
            )
        }
    }
}

private val palette: List<Int> = listOf(
    0xFFC9A7F0, 0xFF7B3FE4, 0xFF3A3F8F, 0xFFFF6FB5, 0xFFFFFFFF,
    0xFF000000, 0xFFFFEB3B, 0xFF4CAF50, 0xFFF44336, 0xFF00BCD4,
).map { it.toInt() }

private fun parseHex(text: String): Int? {
    val t = text.trim().removePrefix("#")
    if (t.length != 6) return null
    val v = t.toLongOrNull(16) ?: return null
    return (0xFF000000L or v).toInt()
}

@Composable
private fun ColorSetting(label: String, value: Int, onChange: (Int) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(label)
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            palette.forEach { c ->
                val selected = c == value
                Box(
                    Modifier
                        .size(30.dp)
                        .clip(CircleShape)
                        .background(Color(c))
                        .border(
                            width = if (selected) 3.dp else 1.dp,
                            color = if (selected) MaterialTheme.colorScheme.secondary else Color.Gray,
                            shape = CircleShape,
                        )
                        .clickable { onChange(c) }
                )
            }
        }
        var hex by remember(value) { mutableStateOf(String.format("#%06X", value and 0xFFFFFF)) }
        OutlinedTextField(
            value = hex,
            onValueChange = {
                hex = it
                val parsed = parseHex(it)
                if (parsed != null) onChange(parsed)
            },
            singleLine = true,
            label = { Text("HEX") },
            modifier = Modifier.width(150.dp),
        )
    }
}
