package com.example.fpsoverlay

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat

/** Квадратная обрезка по центру (для портретных картинок чуть выше центра, где обычно лицо). */
private fun squareBitmap(src: Bitmap, size: Int): Bitmap {
    val side = minOf(src.width, src.height)
    val x = (src.width - side) / 2
    val y = ((src.height - side) * 0.2f).toInt()
    val cropped = Bitmap.createBitmap(src, x, y, side, side)
    return Bitmap.createScaledBitmap(cropped, size, size, true)
}

/** Пустая строка uri = картинка по умолчанию из ресурсов. */
fun loadSquareBitmap(context: Context, uri: String, size: Int = 256): Bitmap? = try {
    val src: Bitmap? = if (uri.isBlank()) {
        BitmapFactory.decodeResource(context.resources, R.drawable.avatar_default)
    } else {
        val u = Uri.parse(uri)
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > 1024) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        context.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, opts) }
    }
    src?.let { squareBitmap(it, size) }
} catch (e: Throwable) {
    null
}

/**
 * Android не даёт приложению поменять собственный значок в лаунчере, поэтому создаём
 * ярлык на рабочем столе с выбранной картинкой, который открывает это же приложение.
 * Возвращает 0 при успехе, иначе код причины.
 */
fun pinIconShortcut(context: Context, uri: String): Int {
    if (!ShortcutManagerCompat.isRequestPinShortcutSupported(context)) return 1
    val bmp = loadSquareBitmap(context, uri) ?: return 2
    val intent = Intent(context, MainActivity::class.java).setAction(Intent.ACTION_MAIN)
    val info = ShortcutInfoCompat.Builder(context, "fps_overlay_" + System.currentTimeMillis())
        .setShortLabel("FPS Overlay")
        .setIcon(IconCompat.createWithBitmap(bmp))
        .setIntent(intent)
        .build()
    return if (ShortcutManagerCompat.requestPinShortcut(context, info, null)) 0 else 3
}
