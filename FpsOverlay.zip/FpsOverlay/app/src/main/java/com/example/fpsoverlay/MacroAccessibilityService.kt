package com.example.fpsoverlay

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.yield
import kotlin.coroutines.resume
import kotlin.math.hypot

enum class MacroMode { IDLE, RECORDING, PLAYING }

/**
 * Автокликер и макросы через службу специальных возможностей.
 * Запись: полноэкранный прозрачный слой ловит касания. Воспроизведение: dispatchGesture.
 */
class MacroAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: MacroAccessibilityService? = null

        val mode = MutableStateFlow(MacroMode.IDLE)
        private const val MAX_RECORD_MS = 180_000L
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var wm: WindowManager? = null

    private var panel: LinearLayout? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var recBtn: TextView? = null
    private var playBtn: TextView? = null
    private var label: TextView? = null

    private var recView: RecordView? = null
    private var recTimeout: Job? = null
    private var playJob: Job? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (MacroStore.panelVisible(this)) showPanel()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // события не нужны, служба только вставляет касания
    }

    override fun onInterrupt() {
        stopPlay()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        cleanup()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanup()
        scope.cancel()
        super.onDestroy()
    }

    private fun cleanup() {
        stopPlay()
        stopRecording(save = false)
        removePanel()
        if (instance === this) instance = null
        mode.value = MacroMode.IDLE
    }

    // ---------------------------------------------------------------- панель управления

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun button(text: String, color: Int, onClick: () -> Unit): TextView = TextView(this).apply {
        this.text = text
        textSize = 20f
        setTextColor(color)
        gravity = Gravity.CENTER
        setPadding(dp(10), dp(6), dp(10), dp(6))
        setOnClickListener { onClick() }
    }

    fun setPanelVisible(v: Boolean) {
        if (v) showPanel() else if (mode.value != MacroMode.RECORDING) removePanel()
    }

    private fun showPanel() {
        val w = wm ?: return
        if (panel != null) return

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(2), dp(4), dp(2))
            background = GradientDrawable().apply {
                cornerRadius = dp(18).toFloat()
                setColor(0xDD0A1236.toInt())
                setStroke(dp(1), 0xFF8CC8FF.toInt())
            }
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12)
            y = dp(120)
        }

        // ручка для перетаскивания
        val handle = TextView(this).apply {
            text = "⠿"
            textSize = 20f
            setTextColor(0xFF8CC8FF.toInt())
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }
        var sx = 0f
        var sy = 0f
        var px = 0
        var py = 0
        handle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; px = params.x; py = params.y
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = px + (e.rawX - sx).toInt()
                    params.y = py + (e.rawY - sy).toInt()
                    try { w.updateViewLayout(root, params) } catch (t: Throwable) { /* окно уже убрано */ }
                }
            }
            true
        }

        val rec = button("●", 0xFFFF5C5C.toInt()) { toggleRecord() }
        val play = button("▶", 0xFF6FE38C.toInt()) { togglePlay() }
        val name = TextView(this).apply {
            textSize = 12f
            setTextColor(0xFFE6EEFF.toInt())
            maxWidth = dp(110)
            maxLines = 1
            setPadding(dp(4), 0, dp(6), 0)
        }
        val close = button("✕", 0xFFB8C4E0.toInt()) {
            if (mode.value == MacroMode.IDLE) {
                MacroStore.setPanelVisible(this, false)
                removePanel()
            }
        }
        root.addView(handle)
        root.addView(rec)
        root.addView(play)
        root.addView(name)
        root.addView(close)

        try {
            w.addView(root, params)
        } catch (t: Throwable) {
            return
        }
        panel = root
        panelParams = params
        recBtn = rec
        playBtn = play
        label = name
        refreshPanel()
    }

    private fun removePanel() {
        val w = wm
        val p = panel
        if (w != null && p != null) {
            try { w.removeView(p) } catch (t: Throwable) { /* уже убрано */ }
        }
        panel = null
        panelParams = null
        recBtn = null
        playBtn = null
        label = null
    }

    /** Панель должна быть выше слоя записи: убираем и добавляем заново. */
    private fun bringPanelToFront() {
        val w = wm ?: return
        val p = panel ?: return
        val lp = panelParams ?: return
        try {
            w.removeView(p)
            w.addView(p, lp)
        } catch (t: Throwable) {
            // не критично
        }
    }

    private fun refreshPanel() {
        val m = mode.value
        recBtn?.text = if (m == MacroMode.RECORDING) "■" else "●"
        playBtn?.text = if (m == MacroMode.PLAYING) "■" else "▶"
        label?.text = when (m) {
            MacroMode.RECORDING -> "запись…"
            MacroMode.PLAYING -> "играет…"
            else -> MacroStore.get(this, MacroStore.selectedId(this))?.name ?: "нет макроса"
        }
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    @Suppress("DEPRECATION")
    private fun screenSize(): Pair<Int, Int> {
        val dm = DisplayMetrics()
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
        return Pair(dm.widthPixels, dm.heightPixels)
    }

    // ---------------------------------------------------------------- запись

    private fun toggleRecord() {
        when (mode.value) {
            MacroMode.RECORDING -> stopRecording(save = true)
            MacroMode.IDLE -> startRecording()
            MacroMode.PLAYING -> toast("Сначала остановите воспроизведение")
        }
    }

    private fun startRecording() {
        val w = wm ?: return
        val rv = RecordView(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        try {
            w.addView(rv, lp)
        } catch (t: Throwable) {
            toast("Не удалось начать запись")
            return
        }
        recView = rv
        mode.value = MacroMode.RECORDING
        bringPanelToFront()
        refreshPanel()
        // страховка: если что-то пошло не так, слой записи не останется на экране навсегда
        recTimeout = scope.launch {
            delay(MAX_RECORD_MS)
            if (mode.value == MacroMode.RECORDING) stopRecording(save = true)
        }
    }

    private fun stopRecording(save: Boolean) {
        recTimeout?.cancel()
        recTimeout = null
        val rv = recView ?: return
        recView = null
        try { wm?.removeView(rv) } catch (t: Throwable) { /* уже убрано */ }
        mode.value = MacroMode.IDLE
        if (save) {
            val (sw, sh) = screenSize()
            val name = "Запись " + java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault())
                .format(java.util.Date())
            val m = rv.buildMacro(sw, sh, name)
            if (m == null) {
                toast("Ничего не записано")
            } else {
                MacroStore.save(this, m)
                MacroStore.setSelected(this, m.id)
                toast("Записано шагов: ${m.steps.size}")
            }
        }
        refreshPanel()
    }

    // ---------------------------------------------------------------- воспроизведение

    private fun togglePlay() {
        when (mode.value) {
            MacroMode.PLAYING -> stopPlay()
            MacroMode.IDLE -> startPlay()
            MacroMode.RECORDING -> toast("Сначала остановите запись")
        }
    }

    private fun startPlay() {
        val m = MacroStore.get(this, MacroStore.selectedId(this))
        if (m == null) {
            toast("Выберите макрос в приложении")
            return
        }
        val (sw, sh) = screenSize()
        if ((sw > sh) != m.land) {
            toast("Макрос записан в другой ориентации экрана")
            return
        }
        mode.value = MacroMode.PLAYING
        refreshPanel()
        val pause = MacroStore.pauseOnTouch(this) && ShizukuShell.isReady()
        if (pause) TouchWatcher.start(scope)
        playJob = scope.launch {
            try {
                runMacro(m, sw, sh, pause)
            } finally {
                TouchWatcher.stop()
                mode.value = MacroMode.IDLE
                refreshPanel()
            }
        }
    }

    fun stopPlay() {
        playJob?.cancel()
        playJob = null
    }

    private suspend fun runMacro(m: Macro, sw: Int, sh: Int, pause: Boolean) {
        val speed = m.speed.coerceIn(0.1f, 10f)
        var loop = 0
        while (currentCoroutineContext().isActive && (m.loops == 0 || loop < m.loops)) {
            for (step in m.steps) {
                delay((step.waitMs / speed).toLong())
                // режим «не мешать»: клики только когда палец пользователя не на экране
                if (pause) while (TouchWatcher.running && TouchWatcher.touching) delay(20)
                if (!dispatchStep(step, sw, sh, speed)) delay(50)
            }
            loop++
            if (m.loopDelayMs > 0) delay(m.loopDelayMs.toLong()) else yield()
        }
    }

    private suspend fun dispatchStep(step: MStep, sw: Int, sh: Int, speed: Float): Boolean {
        val maxEnd = GestureDescription.getMaxGestureDuration()
        val b = GestureDescription.Builder()
        var added = 0
        for (k in step.strokes) {
            val first = k.pts.first()
            val path = Path()
            path.moveTo(first.x * sw, first.y * sh)
            for (i in 1 until k.pts.size) path.lineTo(k.pts[i].x * sw, k.pts[i].y * sh)
            val start = (k.offsetMs / speed).toLong().coerceAtLeast(0L)
            if (start >= maxEnd) continue
            var dur = (k.durMs / speed).toLong().coerceAtLeast(20L)
            if (start + dur > maxEnd) dur = (maxEnd - start).coerceAtLeast(1L)
            b.addStroke(GestureDescription.StrokeDescription(path, start, dur))
            added++
        }
        if (added == 0) return true
        val gesture = b.build()
        return suspendCancellableCoroutine { cont ->
            val ok = dispatchGesture(
                gesture,
                object : AccessibilityService.GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        if (cont.isActive) cont.resume(true)
                    }

                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        if (cont.isActive) cont.resume(false)
                    }
                },
                null
            )
            if (!ok && cont.isActive) cont.resume(false)
        }
    }
}

// ---------------------------------------------------------------- слой записи

private class RawStroke(val startT: Long) {
    var endT: Long = startT
    var lastAddT: Long = startT
    val pts = ArrayList<FloatArray>()
}

private class RawSession(val startT: Long) {
    var endT: Long = startT
    val strokes = ArrayList<RawStroke>()
}

/** Полноэкранный полупрозрачный слой: ловит все касания и превращает их в шаги макроса. */
private class RecordView(context: android.content.Context) : View(context) {
    private val sessions = ArrayList<RawSession>()
    private var cur: RawSession? = null
    private val active = HashMap<Int, RawStroke>()
    private val activePos = HashMap<Int, FloatArray>()
    private val loc = IntArray(2)

    private val border = Paint().apply {
        style = Paint.Style.STROKE
        strokeWidth = 8f
        color = 0xCCFF3B3B.toInt()
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
        setShadowLayer(6f, 0f, 0f, Color.BLACK)
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x88FF3B3B.toInt() }

    init {
        setBackgroundColor(0x22000000)
    }

    private fun begin(e: MotionEvent, idx: Int, ox: Float, oy: Float) {
        val st = RawStroke(e.eventTime)
        st.pts.add(floatArrayOf(e.getX(idx) + ox, e.getY(idx) + oy))
        active[e.getPointerId(idx)] = st
        activePos[e.getPointerId(idx)] = floatArrayOf(e.getX(idx), e.getY(idx))
        cur?.strokes?.add(st)
    }

    private fun end(e: MotionEvent, idx: Int, ox: Float, oy: Float) {
        val id = e.getPointerId(idx)
        val st = active.remove(id) ?: return
        activePos.remove(id)
        st.endT = e.eventTime
        st.pts.add(floatArrayOf(e.getX(idx) + ox, e.getY(idx) + oy))
    }

    private fun addPoint(st: RawStroke, x: Float, y: Float, t: Long) {
        if (t - st.lastAddT >= 25) {
            st.pts.add(floatArrayOf(x, y))
            st.lastAddT = t
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        getLocationOnScreen(loc)
        val ox = loc[0].toFloat()
        val oy = loc[1].toFloat()
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                cur = RawSession(e.eventTime).also { sessions.add(it) }
                begin(e, 0, ox, oy)
            }
            MotionEvent.ACTION_POINTER_DOWN -> begin(e, e.actionIndex, ox, oy)
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) {
                    val id = e.getPointerId(i)
                    val st = active[id] ?: continue
                    for (h in 0 until e.historySize) {
                        addPoint(
                            st,
                            e.getHistoricalX(i, h) + ox,
                            e.getHistoricalY(i, h) + oy,
                            e.getHistoricalEventTime(h),
                        )
                    }
                    addPoint(st, e.getX(i) + ox, e.getY(i) + oy, e.eventTime)
                    activePos[id] = floatArrayOf(e.getX(i), e.getY(i))
                }
            }
            MotionEvent.ACTION_POINTER_UP -> end(e, e.actionIndex, ox, oy)
            MotionEvent.ACTION_UP -> {
                end(e, e.actionIndex, ox, oy)
                finishSession(e.eventTime)
            }
            MotionEvent.ACTION_CANCEL -> {
                for (st in active.values) st.endT = e.eventTime
                finishSession(e.eventTime)
            }
        }
        invalidate()
        return true
    }

    private fun finishSession(t: Long) {
        cur?.endT = t
        cur = null
        active.clear()
        activePos.clear()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawRect(4f, 4f, width - 4f, height - 4f, border)
        text.textSize = height * 0.06f
        canvas.drawText("ЗАПИСЬ", width / 2f, height * 0.14f, text)
        text.textSize = height * 0.035f
        canvas.drawText("Нажимайте так, как должен нажимать макрос", width / 2f, height * 0.20f, text)
        canvas.drawText("Касания сюда не доходят до игры. ■ на панели: стоп", width / 2f, height * 0.245f, text)
        for (p in activePos.values) canvas.drawCircle(p[0], p[1], 44f, dot)
    }

    fun buildMacro(sw: Int, sh: Int, name: String): Macro? {
        val steps = ArrayList<MStep>()
        var prevEnd = -1L
        for (s in sessions) {
            if (s.strokes.isEmpty()) continue
            val strokes = ArrayList<MStroke>()
            for (k in s.strokes.take(10)) {
                val pts = k.pts
                if (pts.isEmpty()) continue
                val first = pts.first()
                var moved = 0f
                for (p in pts) moved = maxOf(moved, hypot(p[0] - first[0], p[1] - first[1]))
                // почти неподвижный палец = обычное нажатие
                val use = if (moved < 14f) listOf(first) else pts
                strokes.add(
                    MStroke(
                        offsetMs = (k.startT - s.startT).toInt().coerceAtLeast(0),
                        durMs = (k.endT - k.startT).toInt().coerceIn(10, 59_000),
                        pts = use.map { MPoint((it[0] / sw).coerceIn(0f, 1f), (it[1] / sh).coerceIn(0f, 1f)) },
                    )
                )
            }
            if (strokes.isEmpty()) continue
            val wait = if (prevEnd < 0) 0 else (s.startT - prevEnd).toInt().coerceAtLeast(0)
            steps.add(MStep(wait, strokes))
            prevEnd = s.endT
        }
        if (steps.isEmpty()) return null
        return Macro(
            id = MacroStore.newId(),
            name = name,
            land = sw > sh,
            sw = sw,
            sh = sh,
            created = System.currentTimeMillis(),
            steps = steps,
        )
    }
}

// ---------------------------------------------------------------- слежение за пальцем пользователя

/**
 * Через Shizuku читает getevent и знает, касается ли пользователь экрана прямо сейчас.
 * Нужен режиму «не мешать»: макрос кликает только пока палец поднят, чтобы не сбрасывать ваше касание.
 */
object TouchWatcher {
    @Volatile var touching = false
    @Volatile var running = false
    @Volatile var status = "выключено"

    private var job: Job? = null
    private var proc: Process? = null

    fun start(scope: CoroutineScope) {
        if (job != null) return
        job = scope.launch(Dispatchers.IO) {
            try {
                val dev = findTouchDevice()
                if (dev == null) {
                    status = "не нашёл сенсорный экран через getevent"
                    return@launch
                }
                val p = ShizukuShell.spawn("getevent -l $dev")
                if (p == null) {
                    status = "не удалось запустить getevent"
                    return@launch
                }
                proc = p
                running = true
                status = "слежу за касаниями ($dev)"
                val slots = HashSet<Int>()
                var slot = 0
                var btn = false
                p.inputStream.bufferedReader().use { r ->
                    while (true) {
                        val line = r.readLine() ?: break
                        var t = line.trim().split(Regex("\\s+"))
                        if (t.isNotEmpty() && t[0].endsWith(":")) t = t.drop(1)
                        if (t.size < 3) continue
                        when (t[1]) {
                            "ABS_MT_SLOT" -> slot = t[2].toLongOrNull(16)?.toInt() ?: slot
                            "ABS_MT_TRACKING_ID" ->
                                if (t[2].lowercase() == "ffffffff") slots.remove(slot) else slots.add(slot)
                            "BTN_TOUCH" -> btn = t[2] == "DOWN"
                        }
                        touching = slots.isNotEmpty() || btn
                    }
                }
            } catch (e: Throwable) {
                // процесс закрыт
            } finally {
                touching = false
                running = false
                try { proc?.destroy() } catch (e: Throwable) { /* уже завершён */ }
                proc = null
            }
        }
    }

    fun stop() {
        try { proc?.destroy() } catch (e: Throwable) { /* уже завершён */ }
        job?.cancel()
        job = null
        touching = false
        running = false
        status = "выключено"
    }

    private fun findTouchDevice(): String? {
        val out = ShizukuShell.exec("getevent -lp") ?: return null
        var cur: String? = null
        for (line in out.lines()) {
            if (line.startsWith("add device")) {
                cur = line.substringAfter(": ", "").trim().ifEmpty { null }
            } else if (cur != null && line.contains("ABS_MT_POSITION_X")) {
                return cur
            }
        }
        return null
    }
}
