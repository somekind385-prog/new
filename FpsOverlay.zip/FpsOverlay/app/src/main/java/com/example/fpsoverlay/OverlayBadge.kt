package com.example.fpsoverlay

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.roundToInt

fun fontFamilyOf(index: Int): FontFamily = when (index) {
    1 -> FontFamily.Monospace
    2 -> FontFamily.Serif
    3 -> FontFamily.Cursive
    4 -> FontFamily.SansSerif
    else -> FontFamily.Default
}

suspend fun loadBitmap(context: Context, uri: String): ImageBitmap? = withContext(Dispatchers.IO) {
    try {
        val u = Uri.parse(uri)
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > 1024) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        context.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?.asImageBitmap()
    } catch (e: Throwable) {
        null
    }
}

/** Плашка. Используется и в оверлее, и в предпросмотре на главном экране. */
@Composable
fun OverlayBadge(stats: Stats, s: OverlaySettings, scaleOverride: Float? = null) {
    val sc = scaleOverride ?: s.scale
    val ctx = LocalContext.current
    val shape = RoundedCornerShape((s.corner * sc).dp)
    val fs = (s.fontSize * sc).sp
    val shadow = if (s.textShadow) Shadow(Color.Black.copy(alpha = 0.85f), Offset(2f, 2f), 4f) else null
    val base = TextStyle(
        color = Color(s.textColor),
        fontSize = fs,
        fontFamily = fontFamilyOf(s.fontFamily),
        fontWeight = FontWeight.Bold,
        shadow = shadow,
        fontFeatureSettings = "tnum",
    )

    var boxMod: Modifier = Modifier
    if (s.borderWidth > 0) {
        boxMod = boxMod.border((s.borderWidth * sc).dp, Color(s.borderColor), shape)
    }
    boxMod = boxMod.clip(shape)

    Box(modifier = boxMod) {
        when (s.bgMode) {
            BG_DEFAULT_IMAGE -> Image(
                painter = painterResource(R.drawable.bg_default),
                contentDescription = null,
                modifier = Modifier.matchParentSize(),
                contentScale = ContentScale.Crop,
                alpha = s.bgAlpha,
            )
            BG_CUSTOM_IMAGE -> {
                val bmp by produceState<ImageBitmap?>(null, s.customImageUri) {
                    value = if (s.customImageUri.isBlank()) null else loadBitmap(ctx, s.customImageUri)
                }
                val b = bmp
                if (b != null) {
                    Image(
                        bitmap = b,
                        contentDescription = null,
                        modifier = Modifier.matchParentSize(),
                        contentScale = ContentScale.Crop,
                        alpha = s.bgAlpha,
                    )
                }
            }
            BG_SOLID -> Box(
                Modifier
                    .matchParentSize()
                    .background(Color(s.bgColor).copy(alpha = s.bgAlpha))
            )
            else -> Unit
        }

        val compact = s.badgeStyle != 0
        Row(
            modifier = Modifier.padding(
                horizontal = ((if (compact) 7 else 10) * sc).dp,
                vertical = ((if (compact) 3 else 6) * sc).dp,
            ),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy((8 * sc).dp),
        ) {
            if (compact) {
                // в компактных видах декора нет
            } else if (s.decor == 3) {
                // Своё фото-декор: размер зарезервирован заранее, плашка не прыгает при загрузке
                val dbmp by produceState<ImageBitmap?>(null, s.decorImageUri) {
                    value = if (s.decorImageUri.isBlank()) null else loadBitmap(ctx, s.decorImageUri)
                }
                val dsize = (s.fontSize * sc * 1.8f * s.decorScale).dp
                Box(Modifier.size(dsize).clip(RoundedCornerShape(dsize * 0.2f))) {
                    val d = dbmp
                    if (d != null) {
                        Image(
                            bitmap = d,
                            contentDescription = null,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop,
                        )
                    }
                }
            } else if (s.decor != 0) {
                Text(
                    text = if (s.decor == 1) "🦋" else "💗",
                    style = base.copy(fontSize = fs * 1.4f),
                )
            }
            when (s.badgeStyle) {
                1 -> CompactLine(stats, s, base, labels = true)
                2 -> CompactLine(stats, s, base, labels = false)
                3 -> FpsOnly(stats, s, base)
                else -> if (s.horizontal) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy((10 * sc).dp),
                    ) { Metrics(stats, s, base) }
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy((2 * sc).dp)) {
                        Metrics(stats, s, base)
                    }
                }
            }
        }
    }
}

private class Part(val label: String, val value: String, val reserve: String, val color: Color? = null)

private fun fpsColorOf(stats: Stats, s: OverlaySettings): Color =
    if (s.fpsDynamic) {
        Color.hsv(((stats.fps ?: 0) / 60f).coerceIn(0f, 1f) * 120f, 0.85f, 0.95f)
    } else Color(s.fpsColor)

private fun fmtRate(bps: Long?): String = when {
    bps == null -> "…"
    bps >= 1_000_000L -> String.format(Locale.US, "%.1fM", bps / 1_000_000f)
    else -> "${bps / 1000}K"
}

/** Новые показатели: frametime, 1% low, температура CPU, GPU, пинг, потери, сеть, мощность. */
private fun extraParts(stats: Stats, s: OverlaySettings): List<Part> {
    val out = ArrayList<Part>()
    if (s.showFrame) {
        out.add(Part("FT", stats.frameMs?.let { String.format(Locale.US, "%.1f мс", it) } ?: "—", "00.0 мс"))
        out.add(Part("1%L", stats.fpsLow1?.toString() ?: "—", "000"))
    }
    if (s.showCpuTemp) {
        out.add(Part("CPU°", stats.cpuTempC?.let { String.format(Locale.US, "%.1f°C", it) } ?: "—", "00.0°C"))
    }
    if (s.showGpu) {
        out.add(Part("GPU", stats.gpuPct?.let { "$it%" } ?: "—", "100%"))
    }
    if (s.showPing) {
        out.add(Part("PING", stats.pingMs?.let { "$it мс" } ?: "—", "000 мс"))
        out.add(Part("LOSS", stats.lossPct?.let { "$it%" } ?: "—", "100%"))
    }
    if (s.showNet) {
        out.add(Part("NET", "↓" + fmtRate(stats.netRxBps) + " ↑" + fmtRate(stats.netTxBps), "↓00.0M ↑00.0M"))
    }
    if (s.showPower) {
        out.add(Part("PWR", stats.powerW?.let { String.format(Locale.US, "%.1f Вт", it) } ?: "—", "00.0 Вт"))
    }
    return out
}

/** Основные показатели в компактном виде (без построчной компоновки и ядер). */
private fun mainParts(stats: Stats, s: OverlaySettings): List<Part> {
    val out = ArrayList<Part>()
    if (s.showFps) out.add(Part("FPS", stats.fps?.toString() ?: "—", "000", fpsColorOf(stats, s)))
    if (s.showCpu) {
        val v = stats.cpuTotal?.let { "${it.roundToInt()}%" }
            ?: stats.freqsMhz.filter { it > 0 }.maxOrNull()?.let { "$it МГц" }
            ?: "…"
        out.add(Part("CPU", v, if (stats.cpuTotal != null) "100%" else "0000 МГц"))
    }
    if (s.showTemp) {
        out.add(Part("BAT", stats.tempC?.let { String.format(Locale.US, "%.1f°C", it) } ?: "…", "00.0°C"))
    }
    if (s.showRam) {
        val v = if (stats.ramTotalMb > 0) {
            String.format(Locale.US, "%.1f/%.1f ГБ", stats.ramUsedMb / 1024f, stats.ramTotalMb / 1024f)
        } else "…"
        out.add(Part("RAM", v, "0.0/00.0 ГБ"))
    }
    return out
}

/** Вид «Компакт» (с подписями) и «Минимум» (только числа): всё в одну строку. */
@Composable
private fun CompactLine(stats: Stats, s: OverlaySettings, base: TextStyle, labels: Boolean) {
    val accent = Color(s.fpsColor)
    val parts = mainParts(stats, s) + extraParts(stats, s)
    if (parts.isEmpty()) {
        Text("—", style = base, maxLines = 1, softWrap = false)
        return
    }
    val text = buildAnnotatedString {
        parts.forEachIndexed { i, p ->
            if (i > 0) append("  ")
            if (labels) {
                withStyle(SpanStyle(color = base.color.copy(alpha = 0.85f))) { append(p.label + " ") }
            }
            withStyle(SpanStyle(color = p.color ?: accent)) { append(p.value) }
        }
    }
    val reserve = parts.joinToString("  ") { p -> if (labels) p.label + " " + p.reserve else p.reserve }
    StaticAnnotated(text, reserve, base)
}

/** Вид «Только FPS»: одно число. */
@Composable
private fun FpsOnly(stats: Stats, s: OverlaySettings, base: TextStyle) {
    val big = base.copy(fontSize = base.fontSize * 1.25f)
    val text = buildAnnotatedString {
        withStyle(SpanStyle(color = fpsColorOf(stats, s))) { append(stats.fps?.toString() ?: "—") }
    }
    StaticAnnotated(text, "000", big)
}

@Composable
private fun StaticAnnotated(text: androidx.compose.ui.text.AnnotatedString, reserve: String, style: TextStyle) {
    Box {
        Text(
            text = reserve,
            style = style.copy(shadow = null),
            maxLines = 1,
            softWrap = false,
            modifier = Modifier.alpha(0f),
        )
        Text(text = text, style = style, maxLines = 1, softWrap = false)
    }
}

@Composable
private fun Metrics(stats: Stats, s: OverlaySettings, base: TextStyle) {
    val accent = Color(s.fpsColor)

    if (s.showFps) {
        val color = if (s.fpsDynamic) {
            Color.hsv(((stats.fps ?: 0) / 60f).coerceIn(0f, 1f) * 120f, 0.85f, 0.95f)
        } else accent
        Metric("FPS", stats.fps?.toString() ?: "—", color, base, reserve = "000")
    }
    if (s.showCpu) {
        val value = stats.cpuTotal?.let { "${it.roundToInt()}%" }
            ?: stats.freqsMhz.filter { it > 0 }.maxOrNull()?.let { "$it МГц" }
            ?: "…"
        val reserve = if (stats.cpuTotal != null) "100%" else "0000 МГц"
        Metric("CPU", value, accent, base, reserve = reserve)
    }
    if (s.showCores) {
        val labels: List<String>
        val reserveLabels: List<String>
        if (stats.cores.isNotEmpty()) {
            labels = stats.cores.mapIndexed { i, v -> "$i:${v.roundToInt()}%" }
            reserveLabels = stats.cores.indices.map { i -> "$i:100%" }
        } else {
            labels = stats.freqsMhz.mapIndexed { i, v -> "$i:" + if (v > 0) "$v" else "off" }
            reserveLabels = stats.freqsMhz.indices.map { i -> "$i:0000" }
        }
        if (labels.isEmpty()) {
            Metric("CORES", "…", accent, base, reserve = "…")
        } else {
            val rows = labels.chunked(4)
            val reserveRows = reserveLabels.chunked(4)
            Column {
                rows.forEachIndexed { r, row ->
                    StaticText(
                        text = row.joinToString("  "),
                        reserve = reserveRows[r].joinToString("  "),
                        style = base.copy(color = accent, fontSize = base.fontSize * 0.85f),
                    )
                }
            }
        }
    }
    if (s.showTemp) {
        Metric("TEMP", stats.tempC?.let { String.format(Locale.US, "%.1f°C", it) } ?: "…", accent, base, reserve = "00.0°C")
    }
    if (s.showRam) {
        val v = if (stats.ramTotalMb > 0) {
            String.format(Locale.US, "%.1f/%.1f ГБ", stats.ramUsedMb / 1024f, stats.ramTotalMb / 1024f)
        } else "…"
        Metric("RAM", v, accent, base, reserve = "0.0/00.0 ГБ")
    }
    for (p in extraParts(stats, s)) {
        Metric(p.label, p.value, accent, base, reserve = p.reserve)
    }
}

/** Текст с зарезервированной шириной: плашка не меняет размер, когда меняются цифры. */
@Composable
private fun StaticText(text: String, reserve: String, style: TextStyle) {
    Box {
        Text(
            text = reserve,
            style = style.copy(shadow = null),
            maxLines = 1,
            softWrap = false,
            modifier = Modifier.alpha(0f),
        )
        Text(text = text, style = style, maxLines = 1, softWrap = false)
    }
}

@Composable
private fun Metric(label: String, value: String, valueColor: Color, base: TextStyle, reserve: String) {
    Box {
        Text(
            text = "$label $reserve",
            style = base.copy(shadow = null),
            maxLines = 1,
            softWrap = false,
            modifier = Modifier.alpha(0f),
        )
        Text(
            text = buildAnnotatedString {
                withStyle(SpanStyle(color = base.color.copy(alpha = 0.85f))) { append("$label ") }
                withStyle(SpanStyle(color = valueColor)) { append(value) }
            },
            style = base,
            maxLines = 1,
            softWrap = false,
        )
    }
}
