package com.example.fpsoverlay

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.roundToInt

fun fontFamilyOf(index: Int): FontFamily = when (index) {
    1 -> FontFamily.Monospace
    2 -> FontFamily.Serif
    3 -> FontFamily.Cursive
    4 -> FontFamily.SansSerif
    else -> FontFamily.Default
}

suspend fun loadBitmap(context: Context, uri: String): ImageBitmap? = withContext(Dispatchers.IO) {
    try {
        val u = Uri.parse(uri)
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > 1024) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        context.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?.asImageBitmap()
    } catch (e: Throwable) {
        null
    }
}

/** Плашка. Используется и в оверлее, и в предпросмотре на главном экране. */
@Composable
fun OverlayBadge(stats: Stats, s: OverlaySettings, scaleOverride: Float? = null) {
    val sc = scaleOverride ?: s.scale
    val ctx = LocalContext.current
    val shape = RoundedCornerShape((s.corner * sc).dp)
    val fs = (s.fontSize * sc).sp
    val shadow = if (s.textShadow) Shadow(Color.Black.copy(alpha = 0.85f), Offset(2f, 2f), 4f) else null
    val base = TextStyle(
        color = Color(s.textColor),
        fontSize = fs,
        fontFamily = fontFamilyOf(s.fontFamily),
        fontWeight = FontWeight.Bold,
        shadow = shadow,
    )

    var boxMod: Modifier = Modifier
    if (s.borderWidth > 0) {
        boxMod = boxMod.border((s.borderWidth * sc).dp, Color(s.borderColor), shape)
    }
    boxMod = boxMod.clip(shape)

    Box(modifier = boxMod) {
        when (s.bgMode) {
            BG_DEFAULT_IMAGE -> Image(
                painter = painterResource(R.drawable.bg_default),
                contentDescription = null,
                modifier = Modifier.matchParentSize(),
                contentScale = ContentScale.Crop,
                alpha = s.bgAlpha,
            )
            BG_CUSTOM_IMAGE -> {
                val bmp by produceState<ImageBitmap?>(null, s.customImageUri) {
                    value = if (s.customImageUri.isBlank()) null else loadBitmap(ctx, s.customImageUri)
                }
                val b = bmp
                if (b != null) {
                    Image(
                        bitmap = b,
                        contentDescription = null,
                        modifier = Modifier.matchParentSize(),
                        contentScale = ContentScale.Crop,
                        alpha = s.bgAlpha,
                    )
                }
            }
            BG_SOLID -> Box(
                Modifier
                    .matchParentSize()
                    .background(Color(s.bgColor).copy(alpha = s.bgAlpha))
            )
            else -> Unit
        }

        Row(
            modifier = Modifier.padding(horizontal = (10 * sc).dp, vertical = (6 * sc).dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy((8 * sc).dp),
        ) {
            if (s.decor != 0) {
                Text(
                    text = if (s.decor == 1) "🦋" else "💗",
                    style = base.copy(fontSize = fs * 1.4f),
                )
            }
            if (s.horizontal) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy((10 * sc).dp),
                ) { Metrics(stats, s, base) }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy((2 * sc).dp)) {
                    Metrics(stats, s, base)
                }
            }
        }
    }
}

@Composable
private fun Metrics(stats: Stats, s: OverlaySettings, base: TextStyle) {
    val accent = Color(s.fpsColor)

    if (s.showFps) {
        val color = if (s.fpsDynamic) {
            Color.hsv(((stats.fps ?: 0) / 60f).coerceIn(0f, 1f) * 120f, 0.85f, 0.95f)
        } else accent
        Metric("FPS", stats.fps?.toString() ?: "—", color, base)
    }
    if (s.showCpu) {
        val value = stats.cpuTotal?.let { "${it.roundToInt()}%" }
            ?: stats.freqsMhz.filter { it > 0 }.maxOrNull()?.let { "$it МГц" }
            ?: "…"
        Metric("CPU", value, accent, base)
    }
    if (s.showCores) {
        val labels: List<String> = if (stats.cores.isNotEmpty()) {
            stats.cores.mapIndexed { i, v -> "$i:${v.roundToInt()}%" }
        } else {
            stats.freqsMhz.mapIndexed { i, v -> "$i:" + if (v > 0) "$v" else "off" }
        }
        if (labels.isEmpty()) {
            Metric("CORES", "…", accent, base)
        } else {
            Column {
                labels.chunked(4).forEach { row ->
                    Text(
                        text = row.joinToString("  "),
                        style = base.copy(color = accent, fontSize = base.fontSize * 0.85f),
                    )
                }
            }
        }
    }
    if (s.showTemp) {
        Metric("TEMP", stats.tempC?.let { String.format(Locale.US, "%.1f°C", it) } ?: "…", accent, base)
    }
    if (s.showRam) {
        val v = if (stats.ramTotalMb > 0) {
            String.format(Locale.US, "%.1f/%.1f ГБ", stats.ramUsedMb / 1024f, stats.ramTotalMb / 1024f)
        } else "…"
        Metric("RAM", v, accent, base)
    }
}

@Composable
private fun Metric(label: String, value: String, valueColor: Color, base: TextStyle) {
    Text(
        text = buildAnnotatedString {
            withStyle(SpanStyle(color = base.color.copy(alpha = 0.85f))) { append("$label ") }
            withStyle(SpanStyle(color = valueColor)) { append(value) }
        },
        style = base,
    )
}
