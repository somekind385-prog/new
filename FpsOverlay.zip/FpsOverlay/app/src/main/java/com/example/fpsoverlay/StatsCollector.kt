package com.example.fpsoverlay

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.net.TrafficStats
import android.os.SystemClock
import android.view.Choreographer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku
import java.io.File
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs
import kotlin.math.roundToInt

/** Обёртка над Shizuku: выполнение shell-команд с правами shell. */
object ShizukuShell {
    private const val REQUEST_CODE = 1001

    fun isRunning(): Boolean = try {
        Shizuku.pingBinder()
    } catch (e: Throwable) {
        false
    }

    fun hasPermission(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    fun isReady(): Boolean = hasPermission()

    fun requestPermission() {
        try {
            Shizuku.requestPermission(REQUEST_CODE)
        } catch (e: Throwable) {
            // Shizuku не запущен
        }
    }

    /** Долгоживущий процесс (например getevent): читать построчно, в конце вызвать destroy(). */
    fun spawn(command: String): Process? {
        return try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            m.isAccessible = true
            val args = arrayOf<Any?>(arrayOf("sh", "-c", "exec $command 2>/dev/null"), null, null)
            m.invoke(null, *args) as Process
        } catch (e: Throwable) {
            null
        }
    }

    /** Shizuku.newProcess закрыт в публичном API, поэтому вызываем через рефлексию. */
    fun exec(command: String): String? {
        return try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            m.isAccessible = true
            val args = arrayOf<Any?>(arrayOf("sh", "-c", "($command) 2>/dev/null"), null, null)
            val process = m.invoke(null, *args) as Process
            val text = process.inputStream.bufferedReader().use { it.readText() }
            process.waitFor()
            text
        } catch (e: Throwable) {
            null
        }
    }
}

/** FPS собственного процесса: считаем кадры Choreographer (по сути частота обновления экрана). */
class ChoreographerFps {
    private val handler = Handler(Looper.getMainLooper())
    private val frames = AtomicInteger(0)

    @Volatile
    private var lastNs = System.nanoTime()

    @Volatile
    private var running = false

    private val callback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            frames.incrementAndGet()
            if (running) Choreographer.getInstance().postFrameCallback(this)
        }
    }

    fun start() {
        if (running) return
        running = true
        frames.set(0)
        lastNs = System.nanoTime()
        handler.post { Choreographer.getInstance().postFrameCallback(callback) }
    }

    fun stop() {
        running = false
        handler.post { Choreographer.getInstance().removeFrameCallback(callback) }
    }

    fun read(): Int {
        val now = System.nanoTime()
        val f = frames.getAndSet(0)
        val dt = (now - lastNs) / 1_000_000_000.0
        lastNs = now
        return if (dt <= 0.0) 0 else (f / dt).roundToInt()
    }
}

/** Общая для службы оверлея и экрана приложения (один процесс) последняя диагностика по игре. */
object FpsDiag {
    @Volatile
    var lastGameInfo: String = "ещё не проверялась (запустите оверлей, откройте игру на 5–10 секунд и вернитесь)"
}

/** Результат измерения: fps == null значит «данных нет» (число не выдумываем). */
data class FpsReading(
    val fps: Int?,
    val info: String,
    val ownApp: Boolean = false,
    val frameMs: Float? = null,
    val low1: Int? = null,
)

/** Метки показа кадров слоя (нс, CLOCK_MONOTONIC) и FPS за последнюю секунду. */
class Lat(val fps: Int, val times: List<Long>)

/**
 * Реальный FPS приложения на переднем плане (только Shizuku).
 * Считаем кадры, которые приложение реально отдало в SurfaceFlinger, а не частоту обновления экрана.
 * Способ A: dumpsys SurfaceFlinger --latency <слой> (метки времени показа кадров).
 * Способ B (запасной): dumpsys SurfaceFlinger --timestats (счётчик кадров слоя, берём прирост за интервал).
 */
class ShellFps(private val ownPackage: String) {
    // История кадров активного слоя за 10 секунд: для frametime и 1% low
    private val hist = ArrayList<Long>()
    private var histLayer = ""
    private var histLast = 0L

    private fun pushFrames(layer: String, times: List<Long>) {
        if (layer != histLayer) {
            hist.clear()
            histLast = 0L
            histLayer = layer
        }
        for (t in times) {
            if (t > histLast) {
                hist.add(t)
                histLast = t
            }
        }
        val cut = System.nanoTime() - 10_000_000_000L
        var drop = 0
        while (drop < hist.size && hist[drop] < cut) drop++
        if (drop > 0) hist.subList(0, drop).clear()
    }

    /** frametime за последнюю секунду (мс) и 1% low (FPS) по худшим кадрам за 10 секунд. */
    private fun frameStats(): Pair<Float?, Int?> {
        if (hist.size < 3) return Pair(null, null)
        val now = System.nanoTime()
        val ivMs = ArrayList<Float>(hist.size)
        val recent = ArrayList<Float>()
        for (i in 1 until hist.size) {
            val d = (hist[i] - hist[i - 1]) / 1e6f
            if (d <= 0f || d > 1000f) continue   // паузы и загрузки не считаем
            ivMs.add(d)
            if (hist[i] > now - 1_000_000_000L) recent.add(d)
        }
        val ft = if (recent.isEmpty()) null else recent.average().toFloat()
        if (ivMs.size < 10) return Pair(ft, null)
        val sorted = ivMs.sortedDescending()
        val n = maxOf(1, sorted.size / 100)
        val worst = sorted.take(n).average().toFloat()
        val low = if (worst > 0f) (1000f / worst).roundToInt() else null
        return Pair(ft, low)
    }

    private var layerPkg = ""
    private var layers: List<String> = emptyList()
    private var layersAt = 0L

    private var timeStatsEnabled = false
    private var prevFrames: Map<String, Long> = emptyMap()
    private var prevFramesAt = 0L

    private var fgDiag = ""
    private var latencyDiag = ""
    private var fgPkg: String? = null
    private var fgAt = 0L
    private var bestLayerCached = ""
    private var discoverAt = 0L

    fun measure(): FpsReading {
        val now = SystemClock.elapsedRealtime()

        // Приложение на экране проверяем раз в секунду, а не на каждом тике (dumpsys window медленный).
        var pkg = fgPkg
        if (pkg == null || now - fgAt > 1000) {
            pkg = foregroundPackage()
            fgPkg = pkg
            fgAt = now
        }
        if (pkg == null) return FpsReading(null, "Shizuku: не определил приложение на экране ($fgDiag)")
        if (pkg == ownPackage) return FpsReading(null, "это окно самого оверлея", ownApp = true)

        if (pkg != layerPkg) {
            layers = emptyList()
            layersAt = 0L
            layerPkg = pkg
            bestLayerCached = ""
            discoverAt = 0L
        }

        // Быстрый путь: одна команда по уже найденному слою игры (позволяет обновляться чаще).
        if (bestLayerCached.isNotEmpty() && now - discoverAt < 3000) {
            val v = latencyFps(bestLayerCached, false)
            if (v != null && v.fps > 0) {
                pushFrames(bestLayerCached, v.times)
                val (ft, low) = frameStats()
                return FpsReading(
                    v.fps, "Shizuku: SurfaceFlinger latency, $pkg, слой ${bestLayerCached.take(40)}",
                    frameMs = ft, low1 = low,
                )
            }
        }

        val refresh = if (layers.isEmpty()) 1000L else 3000L
        if (now - layersAt > refresh) {
            layers = findLayers(pkg)
            layersAt = now
        }

        // Способ A: --latency по слоям (SurfaceView игры первым). Берём максимум по слоям.
        var best = -1
        var bestLayer = ""
        var bestLat: Lat? = null
        latencyDiag = ""
        for ((i, layer) in layers.take(8).withIndex()) {
            val v = latencyFps(layer, i == 0)
            if (v != null && v.fps > best) {
                best = v.fps
                bestLayer = layer
                bestLat = v
            }
        }
        if (best > 0 && bestLat != null) {
            bestLayerCached = bestLayer
            discoverAt = now
            pushFrames(bestLayer, bestLat.times)
            val (ft, low) = frameStats()
            return FpsReading(
                best, "Shizuku: SurfaceFlinger latency, $pkg, слой ${bestLayer.take(40)}",
                frameMs = ft, low1 = low,
            )
        }
        bestLayerCached = ""

        // Способ B: timestats
        val ts = timeStatsFps(pkg)
        if (ts != null && ts > 0) return FpsReading(ts, "Shizuku: SurfaceFlinger timestats, $pkg")

        if (best == 0) return FpsReading(0, "Shizuku: кадры не рисуются, $pkg")
        val sample = layers.firstOrNull()?.take(60) ?: "нет"
        return FpsReading(
            null,
            "Shizuku: нет данных. Приложение: $pkg. Слоёв: ${layers.size}, первый: $sample. " +
                "latency: $latencyDiag. timestats: $tsDiag"
        )
    }

    private var tsDiag = ""

    private fun foregroundPackage(): String? {
        val out = ShizukuShell.exec("dumpsys window | grep -E 'mCurrentFocus|mFocusedApp'")
        if (out == null) {
            fgDiag = "команда не выполнилась, Shizuku не отдаёт shell"
            return null
        }
        val m = Regex("""u\d+\s+([A-Za-z0-9_.]+)/""").find(out)
        if (m == null) {
            fgDiag = "ответ: ${out.trim().take(80).ifEmpty { "пусто" }}"
            return null
        }
        return m.groupValues[1]
    }

    private fun findLayers(pkg: String): List<String> {
        val out = ShizukuShell.exec("dumpsys SurfaceFlinger --list") ?: return emptyList()
        val names = LinkedHashSet<String>()
        for (raw in out.lines()) {
            var line = raw.trim()
            // Новые версии Android: RequestedLayerState{имя слоя parentId=...}
            if (line.startsWith("RequestedLayerState{")) {
                line = line.removePrefix("RequestedLayerState{")
                val idx = line.indexOf(" parentId=")
                line = if (idx >= 0) line.substring(0, idx) else line.trimEnd('}')
            }
            if (line.isEmpty() || !line.contains(pkg) || line.contains('\'')) continue
            if (line.startsWith("ActivityRecord") || line.startsWith("Task") ||
                line.startsWith("Background") || line.startsWith("Bounds") ||
                line.startsWith("WindowToken")
            ) continue
            names.add(line)
        }
        return names.sortedBy { if (it.contains("SurfaceView")) 0 else 1 }
    }

    private fun latencyFps(layer: String, diag: Boolean): Lat? {
        val raw = ShizukuShell.exec("dumpsys SurfaceFlinger --latency '$layer'")
        val first = parseLatency(raw)
        if (diag) {
            latencyDiag = when {
                raw == null -> "команда не выполнилась"
                raw.isBlank() -> "пустой ответ"
                else -> "строк ${raw.lines().size}, начало: ${raw.trim().replace('\n', ' ').take(40)}"
            }
        }
        if (first != null) return first
        // На части прошивок имя слоя нужно без суффикса #N
        val alt = layer.replace(Regex("#\\d+$"), "")
        if (alt == layer) return null
        return parseLatency(ShizukuShell.exec("dumpsys SurfaceFlinger --latency '$alt'"))
    }

    /** Колонка 2 = время фактического показа кадра. Считаем уникальные кадры за последнюю секунду. */
    private fun parseLatency(out: String?): Lat? {
        if (out.isNullOrBlank()) return null
        val times = java.util.TreeSet<Long>()
        for (line in out.lines().drop(1)) {
            val p = line.trim().split(Regex("\\s+"))
            if (p.size < 3) continue
            val t = p[1].toLongOrNull() ?: continue
            if (t <= 0L || t == Long.MAX_VALUE) continue
            times.add(t)
        }
        if (times.isEmpty()) return null
        val now = System.nanoTime()
        val window = 1_000_000_000L
        val recent = times.count { it > now - window && it <= now + 100_000_000L }
        if (recent == 0) return Lat(0, times.toList())
        // Буфер на 128 кадров при очень высоком FPS короче секунды: делим на реальную длину окна.
        val span = (now - maxOf(times.first(), now - window)) / 1e9
        val eff = span.coerceIn(0.3, 1.0)
        return Lat((recent / eff).roundToInt(), times.toList())
    }

    private fun timeStatsFps(pkg: String): Int? {
        if (!timeStatsEnabled) {
            ShizukuShell.exec("dumpsys SurfaceFlinger --timestats -enable")
            timeStatsEnabled = true
        }
        val out = ShizukuShell.exec("dumpsys SurfaceFlinger --timestats -dump")
        if (out == null) { tsDiag = "команда не выполнилась"; return null }
        val pkgLines = out.lines().filter { it.contains(pkg) }
        tsDiag = if (out.isBlank()) "пустой ответ" else
            "строк ${out.lines().size}, с пакетом: ${pkgLines.size}, пример: ${pkgLines.firstOrNull()?.trim()?.take(70) ?: "нет"}"
        val nowMs = SystemClock.elapsedRealtime()
        val cur = HashMap<String, Long>()
        var name: String? = null
        val nameRe = Regex("""(?i)layer_?name\s*[=:]\s*"?(.+?)"?\s*$""")
        val framesRe = Regex("""(?i)total_?frames\s*[=:]\s*(\d+)""")
        for (line in out.lines()) {
            val n = nameRe.find(line.trim())
            if (n != null) { name = n.groupValues[1]; continue }
            val f = framesRe.find(line)
            if (f != null && name != null) {
                if (name.contains(pkg) && !name.startsWith("Background") && !name.startsWith("Bounds")) {
                    cur[name] = f.groupValues[1].toLong()
                }
                name = null
            }
        }
        val prev = prevFrames
        val dt = (nowMs - prevFramesAt) / 1000.0
        prevFrames = cur
        prevFramesAt = nowMs
        if (prev.isEmpty() || dt <= 0.2 || dt > 10.0) return null
        var best = -1L
        for ((k, v) in cur) {
            val d = v - (prev[k] ?: continue)
            if (d >= 0 && d > best) best = d
        }
        return if (best < 0) null else (best / dt).roundToInt()
    }
}

/** Расчёт загрузки CPU по двум снимкам /proc/stat. */
class CpuReader {
    private var prev: Map<String, LongArray> = emptyMap()

    fun update(text: String): Pair<Float, List<Float>>? {
        val cur = LinkedHashMap<String, LongArray>()
        for (line in text.lineSequence()) {
            if (!line.startsWith("cpu")) continue
            val p = line.trim().split(Regex("\\s+"))
            if (p.size < 5) continue
            val v = p.drop(1).mapNotNull { it.toLongOrNull() }
            if (v.size < 4) continue
            val total = v.take(8).sum()
            val idle = v[3] + (v.getOrNull(4) ?: 0L)
            cur[p[0]] = longArrayOf(total, idle)
        }
        val old = prev
        prev = cur
        if (old.isEmpty() || !cur.containsKey("cpu")) return null

        fun pct(key: String): Float? {
            val a = old[key] ?: return null
            val b = cur[key] ?: return null
            val dt = b[0] - a[0]
            val di = b[1] - a[1]
            return if (dt <= 0L) 0f else ((dt - di).toFloat() / dt * 100f).coerceIn(0f, 100f)
        }

        val total = pct("cpu") ?: return null
        val cores = cur.keys
            .filter { it != "cpu" }
            .sortedBy { it.removePrefix("cpu").toIntOrNull() ?: 0 }
            .map { pct(it) ?: 0f }
        return Pair(total, cores)
    }
}

class StatsCollector(private val context: Context) {
    val stats = MutableStateFlow(Stats())

    private var job: Job? = null
    private val cpuReader = CpuReader()
    private val choreographerFps = ChoreographerFps()
    private val shellFps = ShellFps(context.packageName)

    // пинг считается в отдельной корутине, чтобы не тормозить основной цикл
    @Volatile private var pingMs: Int? = null
    @Volatile private var lossPct: Int? = null
    @Volatile private var pingMode = "—"
    private var pingJob: Job? = null

    // температура CPU / нагрузка GPU читаются раз в 2 секунды
    private var sysAt = 0L
    private var cpuTempC: Float? = null
    private var gpuPct: Int? = null
    private var sysMode = "—"

    // скорость сети по всему устройству
    private var netAt = 0L
    private var netRx = 0L
    private var netTx = 0L
    private var netRxBps: Long? = null
    private var netTxBps: Long? = null

    fun start(scope: CoroutineScope, settings: () -> OverlaySettings) {
        if (job != null) return
        choreographerFps.start()
        job = scope.launch(Dispatchers.Default) {
            while (isActive) {
                val s = settings()
                stats.value = collect(s)
                delay(s.intervalMs.toLong())
            }
        }
        pingJob = scope.launch(Dispatchers.IO) { pingLoop(settings) }
    }

    fun stop() {
        job?.cancel()
        job = null
        pingJob?.cancel()
        pingJob = null
        choreographerFps.stop()
    }

    private fun collect(s: OverlaySettings): Stats {
        val useShizuku = s.shizuku && ShizukuShell.isReady()

        // --- FPS ---
        // Choreographer считает кадры самого оверлея = частота экрана (144 Гц), поэтому как FPS
        // игры его НЕ используем. Без реальных данных показываем «—», а не выдуманное число.
        val ownFps = choreographerFps.read()
        var fps: Int? = null
        var fpsMode = "—"
        var frameMs: Float? = null
        var low1: Int? = null
        if (s.showFps || s.showFrame) {
            if (useShizuku) {
                val r = shellFps.measure()
                if (r.ownApp) {
                    fps = null
                    fpsMode = "открыто окно оверлея. Последняя проверка игры: ${FpsDiag.lastGameInfo}"
                } else {
                    fps = r.fps
                    frameMs = r.frameMs
                    low1 = r.low1
                    fpsMode = r.info
                    FpsDiag.lastGameInfo = r.info
                }
            } else {
                fpsMode = "нужен Shizuku: без него реальный FPS игр получить нельзя"
            }
        }

        // --- CPU ---
        var total: Float? = null
        var cores: List<Float> = emptyList()
        var cpuMode = "—"
        var freqs: List<Int> = emptyList()
        if (s.showCpu || s.showCores) {
            freqs = readFreqs()
            var text: String? = null
            if (useShizuku) {
                val t = ShizukuShell.exec("cat /proc/stat")
                if (!t.isNullOrBlank() && t.startsWith("cpu")) {
                    text = t
                    cpuMode = "Shizuku (/proc/stat)"
                }
            }
            if (text == null) {
                val t = readLocalProcStat()
                if (t != null) {
                    text = t
                    cpuMode = "/proc/stat (прямой доступ)"
                }
            }
            if (text != null) {
                val r = cpuReader.update(text)
                if (r != null) {
                    total = r.first
                    cores = r.second
                }
            } else {
                cpuMode = if (freqs.isNotEmpty()) {
                    "Частоты ядер (sysfs), загрузка в % недоступна"
                } else {
                    "Нет данных (нужен Shizuku)"
                }
            }
        }

        // --- Температура батареи и RAM ---
        var temp: Float? = null
        if (s.showTemp) {
            val i = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val raw = i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE) ?: Int.MIN_VALUE
            if (raw != Int.MIN_VALUE) temp = raw / 10f
        }
        var used = 0
        var totalMem = 0
        if (s.showRam) {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            totalMem = (mi.totalMem / (1024 * 1024)).toInt()
            used = totalMem - (mi.availMem / (1024 * 1024)).toInt()
        }

        // --- Температура CPU и нагрузка GPU ---
        if (s.showCpuTemp || s.showGpu) readSys(useShizuku) else sysAt = 0L

        // --- Скорость сети ---
        if (s.showNet) {
            val rx = TrafficStats.getTotalRxBytes()
            val tx = TrafficStats.getTotalTxBytes()
            val now = SystemClock.elapsedRealtime()
            if (rx >= 0 && tx >= 0) {
                if (netAt == 0L) {
                    netRx = rx; netTx = tx; netAt = now
                } else if (now - netAt >= 800) {
                    val dt = (now - netAt).toLong()
                    netRxBps = ((rx - netRx) * 1000 / dt).coerceAtLeast(0)
                    netTxBps = ((tx - netTx) * 1000 / dt).coerceAtLeast(0)
                    netRx = rx; netTx = tx; netAt = now
                }
            }
        } else {
            netAt = 0L
            netRxBps = null
            netTxBps = null
        }

        // --- Мощность батареи (ток * напряжение) ---
        var powerW: Float? = null
        if (s.showPower) {
            try {
                val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                val cur = bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
                val i = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                val mv = i?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0
                if (cur != Long.MIN_VALUE && cur != 0L && mv > 0) {
                    // одни прошивки отдают микроамперы, другие миллиамперы
                    val ua = if (abs(cur) < 20000) abs(cur) * 1000 else abs(cur)
                    powerW = (ua / 1e6 * mv / 1000.0).toFloat()
                }
            } catch (e: Throwable) {
                // нет данных
            }
        }

        return Stats(
            fps = fps,
            fpsMode = fpsMode,
            frameMs = frameMs,
            fpsLow1 = low1,
            cpuTempC = if (s.showCpuTemp) cpuTempC else null,
            gpuPct = if (s.showGpu) gpuPct else null,
            pingMs = if (s.showPing) pingMs else null,
            lossPct = if (s.showPing) lossPct else null,
            netRxBps = netRxBps,
            netTxBps = netTxBps,
            powerW = powerW,
            sysMode = sysMode,
            pingMode = pingMode,
            cpuTotal = total,
            cores = cores,
            freqsMhz = freqs,
            cpuMode = cpuMode,
            tempC = temp,
            ramUsedMb = used,
            ramTotalMb = totalMem,
        )
    }

    private val sysScript =
        "for z in /sys/class/thermal/thermal_zone*; do echo \"T|\$(cat \$z/type)|\$(cat \$z/temp)\"; done; " +
            "echo \"G1|\$(cat /sys/class/kgsl/kgsl-3d0/gpu_busy_percentage)\"; " +
            "echo \"G2|\$(cat /sys/class/kgsl/kgsl-3d0/gpubusy)\""

    /** Температура CPU (зоны thermal) и нагрузка GPU (Qualcomm kgsl). Нужен Shizuku или открытый sysfs. */
    private fun readSys(useShizuku: Boolean) {
        val now = SystemClock.elapsedRealtime()
        if (now - sysAt < 2000) return
        sysAt = now
        var out: String? = if (useShizuku) ShizukuShell.exec(sysScript) else null
        if (out.isNullOrBlank()) out = readThermalDirect()
        if (out.isNullOrBlank()) {
            cpuTempC = null
            gpuPct = null
            sysMode = if (useShizuku) "sysfs пуст: прошивка не отдаёт данные" else "нужен Shizuku"
            return
        }
        var cpuMax: Float? = null
        var socMax: Float? = null
        var cpuZones = 0
        var gpu: Int? = null
        for (line in out.lines()) {
            val p = line.trim().split("|")
            if (p.size < 2) continue
            when (p[0]) {
                "T" -> {
                    if (p.size < 3) continue
                    val type = p[1].trim().lowercase()
                    var c = (p[2].trim().toLongOrNull() ?: continue).toFloat()
                    if (abs(c) > 1000f) c /= 1000f
                    if (c < 10f || c > 120f) continue
                    val isCpu = type.contains("cpu") || type.contains("cluster") ||
                        type == "big" || type == "mid" || type == "little"
                    if (isCpu) {
                        cpuZones++
                        cpuMax = maxOf(cpuMax ?: c, c)
                    } else if (type.contains("soc") || type.contains("tsens")) {
                        socMax = maxOf(socMax ?: c, c)
                    }
                }
                "G1" -> {
                    val v = Regex("\\d+").find(p[1])?.value?.toIntOrNull()
                    if (v != null) gpu = v.coerceIn(0, 100)
                }
                "G2" -> if (gpu == null) {
                    val nums = Regex("\\d+").findAll(p[1]).map { it.value.toLong() }.toList()
                    if (nums.size >= 2 && nums[1] > 0) gpu = (nums[0] * 100 / nums[1]).toInt().coerceIn(0, 100)
                }
            }
        }
        cpuTempC = cpuMax ?: socMax
        gpuPct = gpu
        val socNote = if (cpuMax == null && socMax != null) " (взят датчик SoC)" else ""
        val gpuNote = if (gpu != null) "ок" else "нет данных"
        sysMode = "зон CPU: $cpuZones$socNote; GPU: $gpuNote"
    }

    private fun readThermalDirect(): String? = try {
        val sb = StringBuilder()
        File("/sys/class/thermal").listFiles()?.filter { it.name.startsWith("thermal_zone") }?.forEach { z ->
            val type = try { File(z, "type").readText().trim() } catch (e: Throwable) { "" }
            val temp = try { File(z, "temp").readText().trim() } catch (e: Throwable) { "" }
            if (type.isNotEmpty() && temp.isNotEmpty()) sb.append("T|").append(type).append('|').append(temp).append('\n')
        }
        sb.toString().ifBlank { null }
    } catch (e: Throwable) {
        null
    }

    /** Пинг = время TCP-соединения с сервером, потери = доля неудачных попыток за последние 20 проб. */
    private suspend fun CoroutineScope.pingLoop(settings: () -> OverlaySettings) {
        val results = ArrayDeque<Int>()   // -1 = потеря, иначе миллисекунды
        var lastKey = ""
        while (isActive) {
            val s = settings()
            if (!s.showPing) {
                results.clear()
                pingMs = null
                lossPct = null
                pingMode = "выключено"
                delay(1000)
                continue
            }
            val (host, port) = parseHost(s.pingHost)
            val key = "$host:$port"
            if (key != lastKey) {
                results.clear()
                lastKey = key
            }
            val ms = probe(host, port)
            results.addLast(ms)
            while (results.size > 20) results.removeFirst()
            val ok = results.filter { it >= 0 }
            lossPct = (results.count { it < 0 } * 100f / results.size).roundToInt()
            val recent = results.takeLast(5).filter { it >= 0 }
            pingMs = if (recent.isEmpty()) null else recent.average().roundToInt()
            pingMode = "TCP-соединение до $key" + if (ok.isEmpty()) " (нет ответа)" else ""
            delay(1000)
        }
    }

    private fun parseHost(raw: String): Pair<String, Int> {
        val t = raw.trim().ifEmpty { "1.1.1.1" }
        val i = t.lastIndexOf(':')
        if (i > 0 && t.indexOf(':') == i) {
            val port = t.substring(i + 1).toIntOrNull()
            if (port != null && port in 1..65535) return Pair(t.substring(0, i), port)
        }
        return Pair(t, 443)
    }

    private fun probe(host: String, port: Int): Int = try {
        val addr = InetSocketAddress(host, port)
        if (addr.isUnresolved) {
            -1
        } else {
            val t0 = System.nanoTime()
            Socket().use { it.connect(addr, 1500) }
            ((System.nanoTime() - t0) / 1_000_000).toInt().coerceAtLeast(1)
        }
    } catch (e: Throwable) {
        -1
    }

    private fun readLocalProcStat(): String? = try {
        val t = File("/proc/stat").readText()
        if (t.startsWith("cpu")) t else null
    } catch (e: Throwable) {
        null
    }

    private fun readFreqs(): List<Int> {
        val n = Runtime.getRuntime().availableProcessors()
        val out = ArrayList<Int>()
        for (i in 0 until n) {
            val khz = try {
                File("/sys/devices/system/cpu/cpu$i/cpufreq/scaling_cur_freq").readText().trim().toLong()
            } catch (e: Throwable) {
                null
            }
            out.add(if (khz != null) (khz / 1000).toInt() else -1)
        }
        return if (out.all { it < 0 }) emptyList() else out
    }
}
