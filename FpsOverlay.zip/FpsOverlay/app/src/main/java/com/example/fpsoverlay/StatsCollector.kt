package com.example.fpsoverlay

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Choreographer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku
import java.io.File
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.roundToInt

/** Обёртка над Shizuku: выполнение shell-команд с правами shell. */
object ShizukuShell {
    private const val REQUEST_CODE = 1001

    fun isRunning(): Boolean = try {
        Shizuku.pingBinder()
    } catch (e: Throwable) {
        false
    }

    fun hasPermission(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    fun isReady(): Boolean = hasPermission()

    fun requestPermission() {
        try {
            Shizuku.requestPermission(REQUEST_CODE)
        } catch (e: Throwable) {
            // Shizuku не запущен
        }
    }

    /** Shizuku.newProcess закрыт в публичном API, поэтому вызываем через рефлексию. */
    fun exec(command: String): String? {
        return try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            m.isAccessible = true
            val args = arrayOf<Any?>(arrayOf("sh", "-c", "($command) 2>/dev/null"), null, null)
            val process = m.invoke(null, *args) as Process
            val text = process.inputStream.bufferedReader().use { it.readText() }
            process.waitFor()
            text
        } catch (e: Throwable) {
            null
        }
    }
}

/** FPS собственного процесса: считаем кадры Choreographer (по сути частота обновления экрана). */
class ChoreographerFps {
    private val handler = Handler(Looper.getMainLooper())
    private val frames = AtomicInteger(0)

    @Volatile
    private var lastNs = System.nanoTime()

    @Volatile
    private var running = false

    private val callback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            frames.incrementAndGet()
            if (running) Choreographer.getInstance().postFrameCallback(this)
        }
    }

    fun start() {
        if (running) return
        running = true
        frames.set(0)
        lastNs = System.nanoTime()
        handler.post { Choreographer.getInstance().postFrameCallback(callback) }
    }

    fun stop() {
        running = false
        handler.post { Choreographer.getInstance().removeFrameCallback(callback) }
    }

    fun read(): Int {
        val now = System.nanoTime()
        val f = frames.getAndSet(0)
        val dt = (now - lastNs) / 1_000_000_000.0
        lastNs = now
        return if (dt <= 0.0) 0 else (f / dt).roundToInt()
    }
}

/** Результат измерения: fps == null значит «данных нет» (число не выдумываем). */
data class FpsReading(val fps: Int?, val info: String, val ownApp: Boolean = false)

/**
 * Реальный FPS приложения на переднем плане (только Shizuku).
 * Считаем кадры, которые приложение реально отдало в SurfaceFlinger, а не частоту обновления экрана.
 * Способ A: dumpsys SurfaceFlinger --latency <слой> (метки времени показа кадров).
 * Способ B (запасной): dumpsys SurfaceFlinger --timestats (счётчик кадров слоя, берём прирост за интервал).
 */
class ShellFps(private val ownPackage: String) {
    private var layerPkg = ""
    private var layers: List<String> = emptyList()
    private var layersAt = 0L

    private var timeStatsEnabled = false
    private var prevFrames: Map<String, Long> = emptyMap()
    private var prevFramesAt = 0L

    private var fgDiag = ""
    private var latencyDiag = ""

    fun measure(): FpsReading {
        val pkg = foregroundPackage()
            ?: return FpsReading(null, "Shizuku: не определил приложение на экране ($fgDiag)")
        if (pkg == ownPackage) return FpsReading(null, "это окно самого оверлея", ownApp = true)

        val now = SystemClock.elapsedRealtime()
        val refresh = if (layers.isEmpty()) 1000L else 3000L
        if (pkg != layerPkg || now - layersAt > refresh) {
            layers = findLayers(pkg)
            layerPkg = pkg
            layersAt = now
        }

        // Способ A: --latency по слоям (SurfaceView игры первым). Берём максимум по слоям.
        var best = -1
        var bestLayer = ""
        latencyDiag = ""
        for ((i, layer) in layers.take(8).withIndex()) {
            val v = latencyFps(layer, i == 0)
            if (v != null && v > best) {
                best = v
                bestLayer = layer
            }
        }
        if (best > 0) return FpsReading(best, "Shizuku: SurfaceFlinger latency, $pkg, слой ${bestLayer.take(40)}")

        // Способ B: timestats
        val ts = timeStatsFps(pkg)
        if (ts != null && ts > 0) return FpsReading(ts, "Shizuku: SurfaceFlinger timestats, $pkg")

        if (best == 0) return FpsReading(0, "Shizuku: кадры не рисуются, $pkg")
        val sample = layers.firstOrNull()?.take(60) ?: "нет"
        return FpsReading(
            null,
            "Shizuku: нет данных. Приложение: $pkg. Слоёв: ${layers.size}, первый: $sample. " +
                "latency: $latencyDiag. timestats: $tsDiag"
        )
    }

    private var tsDiag = ""

    private fun foregroundPackage(): String? {
        val out = ShizukuShell.exec("dumpsys window | grep -E 'mCurrentFocus|mFocusedApp'")
        if (out == null) {
            fgDiag = "команда не выполнилась, Shizuku не отдаёт shell"
            return null
        }
        val m = Regex("""u\d+\s+([A-Za-z0-9_.]+)/""").find(out)
        if (m == null) {
            fgDiag = "ответ: ${out.trim().take(80).ifEmpty { "пусто" }}"
            return null
        }
        return m.groupValues[1]
    }

    private fun findLayers(pkg: String): List<String> {
        val out = ShizukuShell.exec("dumpsys SurfaceFlinger --list") ?: return emptyList()
        return out.lines()
            .map { it.trim() }
            .filter { it.contains(pkg) && !it.contains('\'') }
            .filter {
                !it.startsWith("ActivityRecord") && !it.startsWith("Task") &&
                    !it.startsWith("Background") && !it.startsWith("Bounds") &&
                    !it.startsWith("WindowToken")
            }
            .sortedBy { if (it.contains("SurfaceView")) 0 else 1 }
    }

    private fun latencyFps(layer: String, diag: Boolean): Int? {
        val raw = ShizukuShell.exec("dumpsys SurfaceFlinger --latency '$layer'")
        val first = parseLatency(raw)
        if (diag) {
            latencyDiag = when {
                raw == null -> "команда не выполнилась"
                raw.isBlank() -> "пустой ответ"
                else -> "строк ${raw.lines().size}, начало: ${raw.trim().replace('\n', ' ').take(40)}"
            }
        }
        if (first != null) return first
        // На части прошивок имя слоя нужно без суффикса #N
        val alt = layer.replace(Regex("#\\d+$"), "")
        if (alt == layer) return null
        return parseLatency(ShizukuShell.exec("dumpsys SurfaceFlinger --latency '$alt'"))
    }

    /** Колонка 2 = время фактического показа кадра. Считаем уникальные кадры за последнюю секунду. */
    private fun parseLatency(out: String?): Int? {
        if (out.isNullOrBlank()) return null
        val times = java.util.TreeSet<Long>()
        for (line in out.lines().drop(1)) {
            val p = line.trim().split(Regex("\\s+"))
            if (p.size < 3) continue
            val t = p[1].toLongOrNull() ?: continue
            if (t <= 0L || t == Long.MAX_VALUE) continue
            times.add(t)
        }
        if (times.isEmpty()) return null
        val now = System.nanoTime()
        val window = 1_000_000_000L
        val recent = times.count { it > now - window && it <= now + 100_000_000L }
        if (recent == 0) return 0
        // Буфер на 128 кадров при очень высоком FPS короче секунды: делим на реальную длину окна.
        val span = (now - maxOf(times.first(), now - window)) / 1e9
        val eff = span.coerceIn(0.3, 1.0)
        return (recent / eff).roundToInt()
    }

    private fun timeStatsFps(pkg: String): Int? {
        if (!timeStatsEnabled) {
            ShizukuShell.exec("dumpsys SurfaceFlinger --timestats -enable")
            timeStatsEnabled = true
        }
        val out = ShizukuShell.exec("dumpsys SurfaceFlinger --timestats -dump")
        if (out == null) { tsDiag = "команда не выполнилась"; return null }
        tsDiag = if (out.isBlank()) "пустой ответ" else "строк ${out.lines().size}"
        val nowMs = SystemClock.elapsedRealtime()
        val cur = HashMap<String, Long>()
        var name: String? = null
        val nameRe = Regex("""(?i)layer_?name\s*[=:]\s*"?(.+?)"?\s*$""")
        val framesRe = Regex("""(?i)total_?frames\s*[=:]\s*(\d+)""")
        for (line in out.lines()) {
            val n = nameRe.find(line.trim())
            if (n != null) { name = n.groupValues[1]; continue }
            val f = framesRe.find(line)
            if (f != null && name != null) {
                if (name.contains(pkg) && !name.startsWith("Background") && !name.startsWith("Bounds")) {
                    cur[name] = f.groupValues[1].toLong()
                }
                name = null
            }
        }
        val prev = prevFrames
        val dt = (nowMs - prevFramesAt) / 1000.0
        prevFrames = cur
        prevFramesAt = nowMs
        if (prev.isEmpty() || dt <= 0.2 || dt > 10.0) return null
        var best = -1L
        for ((k, v) in cur) {
            val d = v - (prev[k] ?: continue)
            if (d >= 0 && d > best) best = d
        }
        return if (best < 0) null else (best / dt).roundToInt()
    }
}

/** Расчёт загрузки CPU по двум снимкам /proc/stat. */
class CpuReader {
    private var prev: Map<String, LongArray> = emptyMap()

    fun update(text: String): Pair<Float, List<Float>>? {
        val cur = LinkedHashMap<String, LongArray>()
        for (line in text.lineSequence()) {
            if (!line.startsWith("cpu")) continue
            val p = line.trim().split(Regex("\\s+"))
            if (p.size < 5) continue
            val v = p.drop(1).mapNotNull { it.toLongOrNull() }
            if (v.size < 4) continue
            val total = v.take(8).sum()
            val idle = v[3] + (v.getOrNull(4) ?: 0L)
            cur[p[0]] = longArrayOf(total, idle)
        }
        val old = prev
        prev = cur
        if (old.isEmpty() || !cur.containsKey("cpu")) return null

        fun pct(key: String): Float? {
            val a = old[key] ?: return null
            val b = cur[key] ?: return null
            val dt = b[0] - a[0]
            val di = b[1] - a[1]
            return if (dt <= 0L) 0f else ((dt - di).toFloat() / dt * 100f).coerceIn(0f, 100f)
        }

        val total = pct("cpu") ?: return null
        val cores = cur.keys
            .filter { it != "cpu" }
            .sortedBy { it.removePrefix("cpu").toIntOrNull() ?: 0 }
            .map { pct(it) ?: 0f }
        return Pair(total, cores)
    }
}

class StatsCollector(private val context: Context) {
    val stats = MutableStateFlow(Stats())

    private var job: Job? = null
    private val cpuReader = CpuReader()
    private val choreographerFps = ChoreographerFps()
    private val shellFps = ShellFps(context.packageName)
    private var lastGameInfo = "ещё не проверялась (откройте игру на несколько секунд)"

    fun start(scope: CoroutineScope, settings: () -> OverlaySettings) {
        if (job != null) return
        choreographerFps.start()
        job = scope.launch(Dispatchers.Default) {
            while (isActive) {
                val s = settings()
                stats.value = collect(s)
                delay(s.intervalMs.toLong())
            }
        }
    }

    fun stop() {
        job?.cancel()
        job = null
        choreographerFps.stop()
    }

    private fun collect(s: OverlaySettings): Stats {
        val useShizuku = s.shizuku && ShizukuShell.isReady()

        // --- FPS ---
        // Choreographer считает кадры самого оверлея = частота экрана (144 Гц), поэтому как FPS
        // игры его НЕ используем. Без реальных данных показываем «—», а не выдуманное число.
        val ownFps = choreographerFps.read()
        var fps: Int? = null
        var fpsMode = "—"
        if (s.showFps) {
            if (useShizuku) {
                val r = shellFps.measure()
                if (r.ownApp) {
                    fps = null
                    fpsMode = "открыто окно оверлея. Последняя проверка игры: $lastGameInfo"
                } else {
                    fps = r.fps
                    fpsMode = r.info
                    lastGameInfo = r.info
                }
            } else {
                fpsMode = "нужен Shizuku: без него реальный FPS игр получить нельзя"
            }
        }

        // --- CPU ---
        var total: Float? = null
        var cores: List<Float> = emptyList()
        var cpuMode = "—"
        var freqs: List<Int> = emptyList()
        if (s.showCpu || s.showCores) {
            freqs = readFreqs()
            var text: String? = null
            if (useShizuku) {
                val t = ShizukuShell.exec("cat /proc/stat")
                if (!t.isNullOrBlank() && t.startsWith("cpu")) {
                    text = t
                    cpuMode = "Shizuku (/proc/stat)"
                }
            }
            if (text == null) {
                val t = readLocalProcStat()
                if (t != null) {
                    text = t
                    cpuMode = "/proc/stat (прямой доступ)"
                }
            }
            if (text != null) {
                val r = cpuReader.update(text)
                if (r != null) {
                    total = r.first
                    cores = r.second
                }
            } else {
                cpuMode = if (freqs.isNotEmpty()) {
                    "Частоты ядер (sysfs), загрузка в % недоступна"
                } else {
                    "Нет данных (нужен Shizuku)"
                }
            }
        }

        // --- Температура батареи и RAM ---
        var temp: Float? = null
        if (s.showTemp) {
            val i = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val raw = i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE) ?: Int.MIN_VALUE
            if (raw != Int.MIN_VALUE) temp = raw / 10f
        }
        var used = 0
        var totalMem = 0
        if (s.showRam) {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            totalMem = (mi.totalMem / (1024 * 1024)).toInt()
            used = totalMem - (mi.availMem / (1024 * 1024)).toInt()
        }

        return Stats(
            fps = fps,
            fpsMode = fpsMode,
            cpuTotal = total,
            cores = cores,
            freqsMhz = freqs,
            cpuMode = cpuMode,
            tempC = temp,
            ramUsedMb = used,
            ramTotalMb = totalMem,
        )
    }

    private fun readLocalProcStat(): String? = try {
        val t = File("/proc/stat").readText()
        if (t.startsWith("cpu")) t else null
    } catch (e: Throwable) {
        null
    }

    private fun readFreqs(): List<Int> {
        val n = Runtime.getRuntime().availableProcessors()
        val out = ArrayList<Int>()
        for (i in 0 until n) {
            val khz = try {
                File("/sys/devices/system/cpu/cpu$i/cpufreq/scaling_cur_freq").readText().trim().toLong()
            } catch (e: Throwable) {
                null
            }
            out.add(if (khz != null) (khz / 1000).toInt() else -1)
        }
        return if (out.all { it < 0 }) emptyList() else out
    }
}
