package com.example.fpsoverlay

const val BG_DEFAULT_IMAGE = 0
const val BG_CUSTOM_IMAGE = 1
const val BG_SOLID = 2
const val BG_TRANSPARENT = 3

data class OverlaySettings(
    val scale: Float = 1f,
    val fontSize: Int = 14,
    val showFps: Boolean = true,
    val showCpu: Boolean = true,
    val showCores: Boolean = false,
    val showTemp: Boolean = false,
    val showRam: Boolean = false,
    val horizontal: Boolean = false,
    val intervalMs: Int = 1000,
    val bgMode: Int = BG_DEFAULT_IMAGE,
    val bgAlpha: Float = 0.8f,
    val bgColor: Int = 0xFF3A3F8F.toInt(),
    val customImageUri: String = "",
    val textColor: Int = 0xFFFFFFFF.toInt(),
    val fpsColor: Int = 0xFFFF6FB5.toInt(),
    val fpsDynamic: Boolean = true,
    val corner: Int = 16,
    val borderWidth: Int = 2,
    val borderColor: Int = 0xFFC9A7F0.toInt(),
    val textShadow: Boolean = true,
    val fontFamily: Int = 0,
    val decor: Int = 1,
    val decorImageUri: String = "",
    val decorScale: Float = 1f,
    val avatarUri: String = "",
    val appBgPicture: Boolean = true,
    val appBgDim: Float = 0.55f,
    val themeMode: Int = 0,
    val shizuku: Boolean = false,
    val posX: Int = 40,
    val posY: Int = 200,
)

data class Stats(
    val fps: Int? = null,
    val fpsMode: String = "—",
    val cpuTotal: Float? = null,
    val cores: List<Float> = emptyList(),
    val freqsMhz: List<Int> = emptyList(),
    val cpuMode: String = "—",
    val tempC: Float? = null,
    val ramUsedMb: Int = 0,
    val ramTotalMb: Int = 0,
)
