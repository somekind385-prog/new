package com.example.fpsoverlay

import android.content.Context
import android.util.Base64
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream

/** Координаты хранятся долями экрана (0..1), поэтому конфиг подходит телефонам с другим разрешением. */
class MPoint(val x: Float, val y: Float)

/** Один «палец»: когда начинает (offset от начала шага), сколько держит, по какому пути ведёт. */
class MStroke(val offsetMs: Int, val durMs: Int, val pts: List<MPoint>)

/** Шаг = пауза перед ним + одновременные касания (несколько пальцев). */
class MStep(val waitMs: Int, val strokes: List<MStroke>)

data class Macro(
    val id: String,
    val name: String,
    val land: Boolean,        // записан в альбомной ориентации
    val sw: Int,              // размер экрана при записи (для справки)
    val sh: Int,
    val loops: Int = 1,       // 0 = бесконечно
    val loopDelayMs: Int = 0,
    val speed: Float = 1f,
    val created: Long = 0L,
    val steps: List<MStep> = emptyList(),
) {
    /** Примерная длительность одного прохода, мс. */
    fun durationMs(): Long = steps.sumOf { st ->
        st.waitMs.toLong() + (st.strokes.maxOfOrNull { it.offsetMs + it.durMs } ?: 0)
    }
}

private const val MAX_STEPS = 3000
private const val MAX_STROKES = 10
private const val MAX_POINTS = 600
private const val MAX_JSON_BYTES = 4 * 1024 * 1024
const val SHARE_PREFIX = "FPSMACRO1:"

private fun round4(v: Float): Double = Math.round(v * 10000.0) / 10000.0

fun Macro.toJson(): JSONObject {
    val o = JSONObject()
    o.put("v", 1)
    o.put("id", id)
    o.put("name", name)
    o.put("land", land)
    o.put("sw", sw)
    o.put("sh", sh)
    o.put("loops", loops)
    o.put("loopDelay", loopDelayMs)
    o.put("speed", speed.toDouble())
    o.put("ts", created)
    val st = JSONArray()
    for (s in steps) {
        val so = JSONObject()
        so.put("w", s.waitMs)
        val ss = JSONArray()
        for (k in s.strokes) {
            val ko = JSONObject()
            ko.put("o", k.offsetMs)
            ko.put("d", k.durMs)
            val pa = JSONArray()
            for (p in k.pts) pa.put(JSONArray().put(round4(p.x)).put(round4(p.y)))
            ko.put("p", pa)
            ss.put(ko)
        }
        so.put("s", ss)
        st.put(so)
    }
    o.put("steps", st)
    return o
}

/** Разбор с проверками: конфиги приходят от других людей, поэтому все числа ограничены. */
fun parseMacro(o: JSONObject): Macro? {
    return try {
        val stepsJ = o.getJSONArray("steps")
        if (stepsJ.length() == 0 || stepsJ.length() > MAX_STEPS) return null
        val steps = ArrayList<MStep>()
        for (i in 0 until stepsJ.length()) {
            val so = stepsJ.getJSONObject(i)
            val sj = so.getJSONArray("s")
            val strokes = ArrayList<MStroke>()
            for (j in 0 until minOf(sj.length(), MAX_STROKES)) {
                val ko = sj.getJSONObject(j)
                val pj = ko.getJSONArray("p")
                if (pj.length() == 0) continue
                val pts = ArrayList<MPoint>()
                for (q in 0 until minOf(pj.length(), MAX_POINTS)) {
                    val a = pj.getJSONArray(q)
                    pts.add(
                        MPoint(
                            a.getDouble(0).toFloat().coerceIn(0f, 1f),
                            a.getDouble(1).toFloat().coerceIn(0f, 1f),
                        )
                    )
                }
                strokes.add(
                    MStroke(
                        ko.optInt("o", 0).coerceIn(0, 60_000),
                        ko.optInt("d", 50).coerceIn(1, 60_000),
                        pts,
                    )
                )
            }
            if (strokes.isEmpty()) continue
            steps.add(MStep(so.optInt("w", 0).coerceIn(0, 3_600_000), strokes))
        }
        if (steps.isEmpty()) return null
        Macro(
            id = o.optString("id", ""),
            name = o.optString("name", "Макрос").take(60).ifBlank { "Макрос" },
            land = o.optBoolean("land", true),
            sw = o.optInt("sw", 0),
            sh = o.optInt("sh", 0),
            loops = o.optInt("loops", 1).coerceIn(0, 100_000),
            loopDelayMs = o.optInt("loopDelay", 0).coerceIn(0, 3_600_000),
            speed = o.optDouble("speed", 1.0).toFloat().coerceIn(0.1f, 10f),
            created = o.optLong("ts", 0L),
            steps = steps,
        )
    } catch (e: Throwable) {
        null
    }
}

private fun readLimited(stream: InputStream, max: Int): ByteArray? {
    val out = ByteArrayOutputStream()
    val buf = ByteArray(8192)
    var total = 0
    while (true) {
        val n = stream.read(buf)
        if (n < 0) break
        total += n
        if (total > max) return null   // защита от «бомбы» в архиве
        out.write(buf, 0, n)
    }
    return out.toByteArray()
}

/** Текст для отправки другому человеку: префикс + сжатый JSON в base64. */
fun encodeShare(m: Macro): String {
    val json = m.copy(id = "").toJson().toString()
    val bos = ByteArrayOutputStream()
    GZIPOutputStream(bos).use { it.write(json.toByteArray(Charsets.UTF_8)) }
    return SHARE_PREFIX + Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP or Base64.URL_SAFE)
}

/** Принимает и «FPSMACRO1:...», и обычный JSON. */
fun decodeShare(text: String): Macro? {
    val t = text.trim()
    return try {
        val json: String = when {
            t.startsWith(SHARE_PREFIX) -> {
                val b64 = t.removePrefix(SHARE_PREFIX).filter { !it.isWhitespace() }
                val raw = Base64.decode(b64, Base64.URL_SAFE)
                val bytes = GZIPInputStream(ByteArrayInputStream(raw)).use { readLimited(it, MAX_JSON_BYTES) }
                    ?: return null
                String(bytes, Charsets.UTF_8)
            }
            t.startsWith("{") && t.length <= MAX_JSON_BYTES -> t
            else -> return null
        }
        parseMacro(JSONObject(json))
    } catch (e: Throwable) {
        null
    }
}

object MacroStore {
    /** Меняется при любом изменении списка: экран приложения перечитывает макросы. */
    val version = MutableStateFlow(0)

    private const val PREFS = "macro_prefs"

    private fun dir(ctx: Context): File =
        File(ctx.applicationContext.filesDir, "macros").also { it.mkdirs() }

    private fun prefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun newId(): String = java.lang.Long.toString(System.currentTimeMillis(), 36) + (100..999).random()

    fun bump() {
        version.value = version.value + 1
    }

    fun list(ctx: Context): List<Macro> {
        val files = dir(ctx).listFiles { f -> f.extension == "json" } ?: return emptyList()
        return files.mapNotNull { f ->
            try {
                val m = parseMacro(JSONObject(f.readText())) ?: return@mapNotNull null
                m.copy(id = f.nameWithoutExtension, created = if (m.created > 0) m.created else f.lastModified())
            } catch (e: Throwable) {
                null
            }
        }.sortedByDescending { it.created }
    }

    fun get(ctx: Context, id: String): Macro? = if (id.isBlank()) null else list(ctx).firstOrNull { it.id == id }

    fun save(ctx: Context, m: Macro) {
        File(dir(ctx), m.id + ".json").writeText(m.toJson().toString())
        bump()
    }

    fun delete(ctx: Context, id: String) {
        File(dir(ctx), "$id.json").delete()
        if (selectedId(ctx) == id) setSelected(ctx, "")
        bump()
    }

    fun selectedId(ctx: Context): String = prefs(ctx).getString("selected", "") ?: ""

    fun setSelected(ctx: Context, id: String) {
        prefs(ctx).edit().putString("selected", id).apply()
        bump()
    }

    fun pauseOnTouch(ctx: Context): Boolean = prefs(ctx).getBoolean("pauseOnTouch", false)

    fun setPauseOnTouch(ctx: Context, v: Boolean) {
        prefs(ctx).edit().putBoolean("pauseOnTouch", v).apply()
    }

    fun panelVisible(ctx: Context): Boolean = prefs(ctx).getBoolean("panelVisible", true)

    fun setPanelVisible(ctx: Context, v: Boolean) {
        prefs(ctx).edit().putBoolean("panelVisible", v).apply()
    }
}
